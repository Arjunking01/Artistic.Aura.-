import { useMemo, useState } from 'react';
import type { LucideIcon } from 'lucide-react';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { DownloadCard } from '@/components/document/DownloadCard';
import { Button } from '@/components/ui/Button';
import type { Crumb } from '@/components/ui/Breadcrumbs';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob, loadImage, stripExtension } from '../logic/fileUtils';

type ImageFormat = 'image/jpeg' | 'image/png' | 'image/webp';

const EXTENSION: Record<ImageFormat, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const FORMAT_LABEL: Record<ImageFormat, string> = { 'image/jpeg': 'JPG', 'image/png': 'PNG', 'image/webp': 'WEBP' };

interface ImageTransformWorkspaceProps {
  toolName: string;
  tagline: string;
  description: string;
  path: string;
  icon: LucideIcon;
  breadcrumb: Crumb;
  toolSlug: string;
  formatOptions: ImageFormat[] | 'same-as-source';
  allowResize?: boolean;
  allowQuality?: boolean;
  defaultQuality?: number;
}

export function ImageTransformWorkspace({
  toolName, tagline, description, path, icon, breadcrumb, toolSlug,
  formatOptions, allowResize = false, allowQuality = true, defaultQuality = 0.85,
}: ImageTransformWorkspaceProps) {
  const [file, setFile] = useState<File | null>(null);
  const [sourceUrl, setSourceUrl] = useState('');
  const [naturalSize, setNaturalSize] = useState({ width: 0, height: 0 });
  const [width, setWidth] = useState(0);
  const [height, setHeight] = useState(0);
  const [lockAspect, setLockAspect] = useState(true);
  const [format, setFormat] = useState<ImageFormat>('image/jpeg');
  const [quality, setQuality] = useState(defaultQuality);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [result, setResult] = useState<{ blob: Blob; name: string; previewUrl: string } | null>(null);
  const { addEntry } = useToolHistory();

  const availableFormats = useMemo<ImageFormat[]>(() => {
    if (formatOptions === 'same-as-source') return file ? [file.type as ImageFormat] : [];
    return formatOptions;
  }, [formatOptions, file]);

  async function handleFile(files: File[]) {
    const f = files[0];
    if (!f || !f.type.startsWith('image/')) return;
    const url = URL.createObjectURL(f);
    try {
      const img = await loadImage(url);
      setFile(f);
      setSourceUrl(url);
      setNaturalSize({ width: img.width, height: img.height });
      setWidth(img.width);
      setHeight(img.height);
      const initialFormat = formatOptions === 'same-as-source' ? (f.type as ImageFormat) : formatOptions.find((fmt) => fmt !== f.type) ?? formatOptions[0];
      setFormat(initialFormat);
    } catch {
      setErrorMsg('Could not read this image file.');
      setStatus('error');
    }
  }

  function onWidthChange(value: number) {
    if (lockAspect && naturalSize.width) {
      const ratio = naturalSize.height / naturalSize.width;
      setWidth(value);
      setHeight(Math.round(value * ratio));
    } else {
      setWidth(value);
    }
  }

  function onHeightChange(value: number) {
    if (lockAspect && naturalSize.height) {
      const ratio = naturalSize.width / naturalSize.height;
      setHeight(value);
      setWidth(Math.round(value * ratio));
    } else {
      setHeight(value);
    }
  }

  async function process() {
    if (!file) return;
    setStatus('processing');
    try {
      const img = await loadImage(sourceUrl);
      const targetWidth = allowResize ? width : naturalSize.width;
      const targetHeight = allowResize ? height : naturalSize.height;
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d')!;
      if (format === 'image/jpeg') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, targetWidth, targetHeight);
      }
      ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

      const useQuality = allowQuality && format !== 'image/png';
      const blob: Blob = await new Promise((resolve, reject) => {
        canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('encode failed'))), format, useQuality ? quality : undefined);
      });

      const name = `${stripExtension(file.name)}.${EXTENSION[format]}`;
      const previewUrl = URL.createObjectURL(blob);
      setResult({ blob, name, previewUrl });
      addEntry({ tool: toolName, toolSlug, fileName: name, sizeLabel: formatBytes(blob.size) });
      setStatus('success');
    } catch {
      setErrorMsg('Could not process this image. Try a different file or format.');
      setStatus('error');
    }
  }

  function reset() {
    setFile(null);
    setSourceUrl('');
    setResult(null);
    setStatus('idle');
  }

  return (
    <DocumentToolLayout toolName={toolName} tagline={tagline} description={description} path={path} icon={icon} breadcrumb={breadcrumb} toolSlug={toolSlug}>
      <Card>
        {result ? (
          <div className="space-y-4">
            {file && (
              <SoftCard>
                <p className="text-sm text-navy-600 dark:text-ink-300">
                  {formatBytes(file.size)} → <span className="font-semibold text-emerald-500">{formatBytes(result.blob.size)}</span>
                </p>
              </SoftCard>
            )}
            <DownloadCard fileName={result.name} sizeLabel={formatBytes(result.blob.size)} previewUrl={result.previewUrl} onDownload={() => downloadBlob(result.blob, result.name)} onReset={reset} />
          </div>
        ) : !file ? (
          <>
            <FileDropzone accept="image/*" label="Drop an image here" hint="JPG, PNG, or WEBP" onFiles={handleFile} />
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : undefined} />
            </div>
          </>
        ) : (
          <div className="grid sm:grid-cols-[200px_1fr] gap-6">
            <img src={sourceUrl} alt="Preview" className="w-full rounded-xl border border-navy-100 dark:border-white/10 object-cover aspect-square" />

            <div className="space-y-4">
              <p className="text-sm text-navy-500 dark:text-ink-500">{file.name} · {formatBytes(file.size)} · {naturalSize.width}×{naturalSize.height}px</p>

              {allowResize && (
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-sm">
                    Width (px)
                    <input type="number" value={width} onChange={(e) => onWidthChange(Number(e.target.value))} className="mt-1 w-full rounded-lg border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 outline-none focus:border-electric-500" />
                  </label>
                  <label className="text-sm">
                    Height (px)
                    <input type="number" value={height} onChange={(e) => onHeightChange(Number(e.target.value))} className="mt-1 w-full rounded-lg border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 outline-none focus:border-electric-500" />
                  </label>
                  <label className="col-span-2 flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={lockAspect} onChange={(e) => setLockAspect(e.target.checked)} className="accent-electric-500" />
                    Lock aspect ratio
                  </label>
                </div>
              )}

              {availableFormats.length > 1 && (
                <div>
                  <p className="text-sm font-medium text-navy-700 dark:text-ink-300 mb-1.5">Output format</p>
                  <div className="flex gap-2">
                    {availableFormats.map((fmt) => (
                      <button
                        key={fmt}
                        onClick={() => setFormat(fmt)}
                        className={`rounded-lg px-3.5 py-1.5 text-sm font-medium border transition-colors ${format === fmt ? 'border-electric-500 bg-electric-500/10 text-electric-500' : 'border-navy-200 dark:border-white/10 text-navy-500 dark:text-ink-400'}`}
                      >
                        {FORMAT_LABEL[fmt]}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {allowQuality && format !== 'image/png' && (
                <label className="block text-sm">
                  Quality — {Math.round(quality * 100)}%
                  <input type="range" min={0.1} max={1} step={0.05} value={quality} onChange={(e) => setQuality(Number(e.target.value))} className="mt-1 w-full accent-electric-500" />
                </label>
              )}

              <div className="flex items-center gap-3 pt-2">
                <Button onClick={process}>Process image</Button>
                <Button variant="ghost" onClick={reset}>Choose another</Button>
              </div>
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : undefined} />
            </div>
          </div>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
