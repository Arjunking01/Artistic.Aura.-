import type { LucideIcon } from 'lucide-react';
import { Layers } from 'lucide-react';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { Seo } from '@/components/Seo';
import type { Crumb } from '@/components/ui/Breadcrumbs';

interface PipelineStage {
  title: string;
  detail: string;
}

interface ArchitecturePreviewPageProps {
  toolName: string;
  tagline: string;
  description: string;
  path: string;
  icon: LucideIcon;
  breadcrumb: Crumb;
  toolSlug: string;
  whyClientSideIsntEnough: string;
  stages: PipelineStage[];
}

/** Describes a planned processing pipeline honestly, without simulating a result the tool can't yet produce. */
export function ArchitecturePreviewPage({
  toolName, tagline, description, path, icon, breadcrumb, toolSlug, whyClientSideIsntEnough, stages,
}: ArchitecturePreviewPageProps) {
  return (
    <DocumentToolLayout toolName={toolName} tagline={tagline} description={description} path={path} icon={icon} breadcrumb={breadcrumb} toolSlug={toolSlug} showHistory={false}>
      <Seo title={toolName} description={description} path={path} />
      <Card>
        <SoftCard className="mb-6 flex items-start gap-3">
          <Layers size={18} className="text-violet-500 shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-navy-900 dark:text-ink-100 mb-1">This tool is architected, not yet fully live</p>
            <p className="text-sm text-navy-600 dark:text-ink-300">{whyClientSideIsntEnough}</p>
          </div>
        </SoftCard>

        <h2 className="font-semibold text-lg mb-4">Planned processing pipeline</h2>
        <ol className="space-y-3">
          {stages.map((stage, i) => (
            <li key={stage.title} className="flex gap-3">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full gradient-brand text-xs font-semibold text-white">{i + 1}</span>
              <div>
                <p className="font-medium text-navy-900 dark:text-ink-100">{stage.title}</p>
                <p className="text-sm text-navy-500 dark:text-ink-400">{stage.detail}</p>
              </div>
            </li>
          ))}
        </ol>
      </Card>
    </DocumentToolLayout>
  );
}
