import { RotateCw } from 'lucide-react';
import { PdfPageWorkspace } from '../components/PdfPageWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('rotate-pdf')!;

export default function RotatePdfPage() {
  return (
    <PdfPageWorkspace
      mode="rotate"
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/rotate-pdf" icon={RotateCw} breadcrumb={{ label: 'Rotate PDF' }} toolSlug={tool.slug}
    />
  );
}
