import { ScanText } from 'lucide-react';
import { ArchitecturePreviewPage } from '../components/ArchitecturePreviewPage';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('ocr-architecture')!;

export default function OcrArchitecturePage() {
  return (
    <ArchitecturePreviewPage
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/ocr-architecture" icon={ScanText} breadcrumb={{ label: 'OCR' }} toolSlug={tool.slug}
      whyClientSideIsntEnough="Accurate OCR for scanned pages and photographed notes needs a trained text-recognition model. Running that reliably in-browser for every device, language, and handwriting style isn't practical yet — so this is scoped for a dedicated OCR pass rather than a partial, unreliable client-side guess."
      stages={[
        { title: 'Upload scanned file', detail: 'Accept a scanned PDF or photographed page (JPG/PNG).' },
        { title: 'Page rasterization', detail: 'Convert each page into a high-resolution image, reusing the same rendering pipeline as PDF to Image.' },
        { title: 'Text recognition pass', detail: 'Run each image through an OCR engine to detect and transcribe text, including basic layout structure.' },
        { title: 'Review & export', detail: 'Show extracted text next to the original page for quick correction, then export as .txt or a searchable PDF.' },
      ]}
    />
  );
}
