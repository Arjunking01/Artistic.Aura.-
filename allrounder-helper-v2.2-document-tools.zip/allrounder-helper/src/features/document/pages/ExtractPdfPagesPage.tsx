import { FileOutput } from 'lucide-react';
import { PdfPageWorkspace } from '../components/PdfPageWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('extract-pdf-pages')!;

export default function ExtractPdfPagesPage() {
  return (
    <PdfPageWorkspace
      mode="extract"
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/extract-pdf-pages" icon={FileOutput} breadcrumb={{ label: 'Extract Pages' }} toolSlug={tool.slug}
    />
  );
}
