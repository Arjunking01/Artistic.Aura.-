import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Seo, SITE_URL } from '@/components/Seo';
import { Breadcrumbs, breadcrumbJsonLd } from '@/components/ui/Breadcrumbs';
import { documentTools, categoryLabels, type DocumentCategory } from '@/data/documentToolsRegistry';

const CATEGORY_ORDER: DocumentCategory[] = ['pdf', 'conversion', 'image', 'qr'];

export default function DocumentToolsIndexPage() {
  return (
    <div className="noise-bg">
      <Seo
        title="Document & Image Tools"
        description="Free browser-based PDF, image, and QR tools for students — merge, split, compress, convert, crop, and generate codes without uploading to a server."
        path="/document-tools"
        jsonLd={breadcrumbJsonLd([{ label: 'Document Tools' }], SITE_URL)}
      />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 pt-8">
        <Breadcrumbs items={[{ label: 'Document Tools' }]} />
      </div>
      <header className="mx-auto max-w-6xl px-4 sm:px-6 pt-8 pb-10">
        <h1 className="text-3xl sm:text-4xl font-semibold">Document & Image Tools</h1>
        <p className="mt-3 text-navy-500 dark:text-ink-400 max-w-2xl">
          PDF, image, and QR tools that run entirely in your browser — your files are processed locally and never uploaded to a server.
        </p>
      </header>

      <div className="mx-auto max-w-6xl px-4 sm:px-6 pb-24 space-y-12">
        {CATEGORY_ORDER.map((category) => (
          <section key={category}>
            <h2 className="text-xl font-semibold mb-4">{categoryLabels[category]}</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {documentTools.filter((t) => t.category === category).map((tool, i) => (
                <motion.div key={tool.slug} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.3, delay: i * 0.03 }}>
                  <Link
                    to={`/document-tools/${tool.slug}`}
                    className="group relative flex flex-col gap-3 rounded-2xl border border-navy-100 dark:border-white/10 p-5 hover:border-electric-500 hover:shadow-lg hover:shadow-electric-500/5 transition-all h-full"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-brand text-white">
                      <tool.icon size={18} />
                    </div>
                    <div>
                      <h3 className="font-semibold group-hover:text-electric-500 transition-colors">{tool.name}</h3>
                      <p className="text-sm text-navy-500 dark:text-ink-500 mt-1">{tool.tagline}</p>
                    </div>
                    {tool.architectureOnly && (
                      <span className="absolute top-4 right-4 text-[10px] font-semibold uppercase tracking-wide text-violet-500 bg-violet-500/10 rounded-full px-2 py-1">
                        Architecture preview
                      </span>
                    )}
                  </Link>
                </motion.div>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
