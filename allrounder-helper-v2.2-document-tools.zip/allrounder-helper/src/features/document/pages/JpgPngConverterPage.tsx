import { FileImage } from 'lucide-react';
import { ImageTransformWorkspace } from '../components/ImageTransformWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('jpg-png-converter')!;

export default function JpgPngConverterPage() {
  return (
    <ImageTransformWorkspace
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/jpg-png-converter" icon={FileImage} breadcrumb={{ label: 'JPG ↔ PNG Converter' }} toolSlug={tool.slug}
      formatOptions={['image/jpeg', 'image/png']}
      allowQuality
    />
  );
}
