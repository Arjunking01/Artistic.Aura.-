import { useEffect, useRef, useState } from 'react';
import { Barcode as BarcodeIcon } from 'lucide-react';
import JsBarcode from 'jsbarcode';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('barcode-generator')!;

export default function BarcodeGeneratorPage() {
  const [value, setValue] = useState('123456789012');
  const [error, setError] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { addEntry } = useToolHistory();

  useEffect(() => {
    if (!canvasRef.current) return;
    try {
      JsBarcode(canvasRef.current, value || ' ', { format: 'CODE128', width: 2, height: 100, displayValue: true, background: '#ffffff', lineColor: '#0a0e1a' });
      setError('');
    } catch {
      setError('This value can\'t be encoded as a CODE128 barcode.');
    }
  }, [value]);

  function download() {
    canvasRef.current?.toBlob((blob) => {
      if (!blob) return;
      downloadBlob(blob, 'barcode.png');
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: 'barcode.png', sizeLabel: formatBytes(blob.size) });
    });
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/barcode-generator" icon={BarcodeIcon} breadcrumb={{ label: 'Barcode Generator' }} toolSlug={tool.slug}
    >
      <Card>
        <label className="block text-sm font-medium text-navy-700 dark:text-ink-300 mb-4">
          Text or number to encode
          <input
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="mt-1.5 w-full rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20"
          />
        </label>

        {error && <p className="text-sm text-red-500 mb-4">{error}</p>}

        <div className="flex items-center justify-center rounded-2xl border border-navy-100 dark:border-white/10 p-6 bg-white mb-5">
          <canvas ref={canvasRef} />
        </div>

        <Button onClick={download}>Download PNG</Button>
      </Card>
    </DocumentToolLayout>
  );
}
