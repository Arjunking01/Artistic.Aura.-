import { useState } from 'react';
import { Scissors } from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import JSZip from 'jszip';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { DownloadCard } from '@/components/document/DownloadCard';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob, stripExtension } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('split-pdf')!;

export default function SplitPdfPage() {
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [result, setResult] = useState<{ blob: Blob; name: string; pageCount: number } | null>(null);
  const { addEntry } = useToolHistory();

  async function processFile(files: File[]) {
    const file = files[0];
    if (!file || file.type !== 'application/pdf') return;
    setStatus('processing');
    try {
      const bytes = await file.arrayBuffer();
      const src = await PDFDocument.load(bytes);
      const pageCount = src.getPageCount();
      const zip = new JSZip();
      const baseName = stripExtension(file.name);

      for (let i = 0; i < pageCount; i++) {
        const single = await PDFDocument.create();
        const [page] = await single.copyPages(src, [i]);
        single.addPage(page);
        const pageBytes = await single.save();
        zip.file(`${baseName}-page-${i + 1}.pdf`, pageBytes);
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const name = `${baseName}-split.zip`;
      setResult({ blob: zipBlob, name, pageCount });
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: name, sizeLabel: formatBytes(zipBlob.size) });
      setStatus('success');
    } catch {
      setErrorMsg('Could not split this PDF. It may be encrypted or corrupted.');
      setStatus('error');
    }
  }

  function reset() {
    setResult(null);
    setStatus('idle');
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/split-pdf" icon={Scissors} breadcrumb={{ label: 'Split PDF' }} toolSlug={tool.slug}
    >
      <Card>
        {result ? (
          <div className="space-y-4">
            <p className="text-sm text-navy-600 dark:text-ink-300">
              Split into <span className="font-semibold">{result.pageCount}</span> individual page{result.pageCount !== 1 ? 's' : ''}, packaged as a ZIP.
            </p>
            <DownloadCard fileName={result.name} sizeLabel={formatBytes(result.blob.size)} onDownload={() => downloadBlob(result.blob, result.name)} onReset={reset} />
          </div>
        ) : (
          <>
            <FileDropzone accept="application/pdf" label="Drop a PDF here" hint="Splits into one PDF per page" onFiles={processFile} />
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : 'Splitting pages...'} />
            </div>
          </>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
