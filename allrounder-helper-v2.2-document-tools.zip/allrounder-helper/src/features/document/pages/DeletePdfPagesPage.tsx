import { FileMinus } from 'lucide-react';
import { PdfPageWorkspace } from '../components/PdfPageWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('delete-pdf-pages')!;

export default function DeletePdfPagesPage() {
  return (
    <PdfPageWorkspace
      mode="delete"
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/delete-pdf-pages" icon={FileMinus} breadcrumb={{ label: 'Delete Pages' }} toolSlug={tool.slug}
    />
  );
}
