import { RefreshCw } from 'lucide-react';
import { ImageTransformWorkspace } from '../components/ImageTransformWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('image-format-converter')!;

export default function ImageFormatConverterPage() {
  return (
    <ImageTransformWorkspace
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/image-format-converter" icon={RefreshCw} breadcrumb={{ label: 'Image Format Converter' }} toolSlug={tool.slug}
      formatOptions={['image/jpeg', 'image/png', 'image/webp']}
      allowQuality
    />
  );
}
