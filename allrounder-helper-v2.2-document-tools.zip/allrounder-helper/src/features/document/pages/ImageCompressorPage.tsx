import { ImageIcon } from 'lucide-react';
import { ImageTransformWorkspace } from '../components/ImageTransformWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('image-compressor')!;

export default function ImageCompressorPage() {
  return (
    <ImageTransformWorkspace
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/image-compressor" icon={ImageIcon} breadcrumb={{ label: 'Image Compressor' }} toolSlug={tool.slug}
      formatOptions={['image/jpeg', 'image/webp']}
      allowQuality
      defaultQuality={0.7}
    />
  );
}
