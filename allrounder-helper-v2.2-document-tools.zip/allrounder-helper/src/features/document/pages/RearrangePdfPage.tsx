import { ArrowUpDown } from 'lucide-react';
import { PdfPageWorkspace } from '../components/PdfPageWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('rearrange-pdf')!;

export default function RearrangePdfPage() {
  return (
    <PdfPageWorkspace
      mode="rearrange"
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/rearrange-pdf" icon={ArrowUpDown} breadcrumb={{ label: 'Rearrange Pages' }} toolSlug={tool.slug}
    />
  );
}
