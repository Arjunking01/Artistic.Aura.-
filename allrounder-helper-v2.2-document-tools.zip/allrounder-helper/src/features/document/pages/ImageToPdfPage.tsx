import { useState } from 'react';
import { ImagePlus, ArrowUp, ArrowDown, X } from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { DownloadCard } from '@/components/document/DownloadCard';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('image-to-pdf')!;

interface ImageEntry {
  file: File;
  previewUrl: string;
}

export default function ImageToPdfPage() {
  const [images, setImages] = useState<ImageEntry[]>([]);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [result, setResult] = useState<{ blob: Blob; name: string } | null>(null);
  const { addEntry } = useToolHistory();

  function addFiles(files: File[]) {
    const valid = files.filter((f) => f.type.startsWith('image/'));
    setImages((prev) => [...prev, ...valid.map((file) => ({ file, previewUrl: URL.createObjectURL(file) }))]);
  }

  function move(index: number, dir: -1 | 1) {
    setImages((prev) => {
      const next = [...prev];
      const target = index + dir;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function removeImage(index: number) {
    setImages((prev) => prev.filter((_, i) => i !== index));
  }

  async function convert() {
    if (images.length === 0) return;
    setStatus('processing');
    try {
      const doc = await PDFDocument.create();
      for (const { file } of images) {
        const bytes = await file.arrayBuffer();
        const isPng = file.type === 'image/png';
        const embedded = isPng ? await doc.embedPng(bytes) : await doc.embedJpg(bytes);
        const page = doc.addPage([embedded.width, embedded.height]);
        page.drawImage(embedded, { x: 0, y: 0, width: embedded.width, height: embedded.height });
      }
      const bytes = await doc.save();
      const blob = new Blob([bytes as BlobPart], { type: 'application/pdf' });
      const name = 'images.pdf';
      setResult({ blob, name });
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: name, sizeLabel: formatBytes(blob.size) });
      setStatus('success');
    } catch {
      setErrorMsg('Could not convert these images. Only JPG and PNG are supported.');
      setStatus('error');
    }
  }

  function reset() {
    setImages([]);
    setResult(null);
    setStatus('idle');
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/image-to-pdf" icon={ImagePlus} breadcrumb={{ label: 'Image to PDF' }} toolSlug={tool.slug}
    >
      <Card>
        {result ? (
          <DownloadCard fileName={result.name} sizeLabel={formatBytes(result.blob.size)} onDownload={() => downloadBlob(result.blob, result.name)} onReset={reset} />
        ) : (
          <>
            <FileDropzone accept="image/jpeg,image/png" multiple label="Drop images here" hint="JPG or PNG" onFiles={addFiles} />

            {images.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
                {images.map((img, i) => (
                  <div key={img.previewUrl} className="relative rounded-xl border border-navy-100 dark:border-white/10 p-2">
                    <img src={img.previewUrl} alt={img.file.name} className="w-full aspect-square object-cover rounded-lg" />
                    <p className="text-center text-xs text-navy-500 dark:text-ink-500 mt-1">Page {i + 1}</p>
                    <div className="absolute top-2 right-2 flex gap-1">
                      <button onClick={() => move(i, -1)} disabled={i === 0} aria-label="Move earlier" className="flex h-6 w-6 items-center justify-center rounded-md bg-white/90 dark:bg-navy-900/90 shadow disabled:opacity-30">
                        <ArrowUp size={12} />
                      </button>
                      <button onClick={() => move(i, 1)} disabled={i === images.length - 1} aria-label="Move later" className="flex h-6 w-6 items-center justify-center rounded-md bg-white/90 dark:bg-navy-900/90 shadow disabled:opacity-30">
                        <ArrowDown size={12} />
                      </button>
                      <button onClick={() => removeImage(i)} aria-label="Remove image" className="flex h-6 w-6 items-center justify-center rounded-md bg-white/90 dark:bg-navy-900/90 shadow text-red-500">
                        <X size={12} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-5 flex items-center gap-3">
              <Button disabled={images.length === 0} onClick={convert}>Convert to PDF</Button>
              {images.length > 0 && <Button variant="ghost" onClick={reset}>Clear</Button>}
            </div>
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : undefined} />
            </div>
          </>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
