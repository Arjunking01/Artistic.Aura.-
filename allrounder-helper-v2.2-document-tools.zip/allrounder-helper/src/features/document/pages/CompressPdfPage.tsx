import { useState } from 'react';
import { Minimize2 } from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { DownloadCard } from '@/components/document/DownloadCard';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob, stripExtension } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('compress-pdf')!;

export default function CompressPdfPage() {
  const [originalSize, setOriginalSize] = useState<number | null>(null);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [result, setResult] = useState<{ blob: Blob; name: string } | null>(null);
  const { addEntry } = useToolHistory();

  async function processFile(files: File[]) {
    const file = files[0];
    if (!file || file.type !== 'application/pdf') return;
    setOriginalSize(file.size);
    setStatus('processing');
    try {
      const bytes = await file.arrayBuffer();
      const doc = await PDFDocument.load(bytes);
      const output = await doc.save({ useObjectStreams: true, addDefaultPage: false });
      const blob = new Blob([output as BlobPart], { type: 'application/pdf' });
      const name = `${stripExtension(file.name)}-compressed.pdf`;
      setResult({ blob, name });
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: name, sizeLabel: formatBytes(blob.size) });
      setStatus('success');
    } catch {
      setErrorMsg('Could not compress this PDF. It may be encrypted or corrupted.');
      setStatus('error');
    }
  }

  function reset() {
    setResult(null);
    setOriginalSize(null);
    setStatus('idle');
  }

  const savedPercent = result && originalSize ? Math.max(0, Math.round((1 - result.blob.size / originalSize) * 100)) : null;

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/compress-pdf" icon={Minimize2} breadcrumb={{ label: 'Compress PDF' }} toolSlug={tool.slug}
    >
      <Card>
        {result ? (
          <div className="space-y-4">
            {savedPercent !== null && (
              <SoftCard>
                <p className="text-sm text-navy-600 dark:text-ink-300">
                  {savedPercent > 0
                    ? <>Reduced file size by <span className="font-semibold text-emerald-500">{savedPercent}%</span> — from {formatBytes(originalSize!)} to {formatBytes(result.blob.size)}.</>
                    : 'This PDF was already tightly optimized — file size stayed about the same.'}
                </p>
              </SoftCard>
            )}
            <DownloadCard fileName={result.name} sizeLabel={formatBytes(result.blob.size)} onDownload={() => downloadBlob(result.blob, result.name)} onReset={reset} />
          </div>
        ) : (
          <>
            <FileDropzone accept="application/pdf" label="Drop a PDF here" hint="PDF only" onFiles={processFile} />
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : 'Compressing...'} />
            </div>
            {status === 'error' && <Button className="mt-3" variant="ghost" onClick={reset}>Try another file</Button>}
          </>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
