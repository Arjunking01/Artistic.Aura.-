import { FileType2 } from 'lucide-react';
import { ArchitecturePreviewPage } from '../components/ArchitecturePreviewPage';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('word-to-pdf')!;

export default function WordToPdfPage() {
  return (
    <ArchitecturePreviewPage
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/word-to-pdf" icon={FileType2} breadcrumb={{ label: 'Word to PDF' }} toolSlug={tool.slug}
      whyClientSideIsntEnough="Faithfully rendering .docx layout, fonts, and pagination into a PDF requires a full document-layout engine — something no in-browser library reproduces reliably yet. We'd rather ship this correctly than approximate it."
      stages={[
        { title: 'Upload & validate', detail: 'Accept a .docx file and confirm it opens as a valid Office Open XML document.' },
        { title: 'Layout rendering service', detail: 'Send the document to a dedicated rendering service that preserves fonts, styles, and pagination exactly as Word displays them.' },
        { title: 'PDF generation', detail: 'Produce a PDF from the rendered layout and return it to your browser.' },
        { title: 'Local cleanup', detail: 'Discard the uploaded file from the service immediately after conversion — nothing is retained.' },
      ]}
    />
  );
}
