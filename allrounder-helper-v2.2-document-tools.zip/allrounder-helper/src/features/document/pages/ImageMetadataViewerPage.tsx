import { useState } from 'react';
import { Info, Download } from 'lucide-react';
import exifr from 'exifr';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob, loadImage, stripExtension } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('image-metadata-viewer')!;

interface MetadataResult {
  fileName: string;
  fileSize: number;
  width: number;
  height: number;
  type: string;
  exif: Record<string, unknown> | null;
}

export default function ImageMetadataViewerPage() {
  const [meta, setMeta] = useState<MetadataResult | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const { addEntry } = useToolHistory();

  async function handleFile(files: File[]) {
    const file = files[0];
    if (!file || !file.type.startsWith('image/')) return;
    setStatus('processing');
    try {
      const url = URL.createObjectURL(file);
      const img = await loadImage(url);
      let exif: Record<string, unknown> | null = null;
      try {
        exif = await exifr.parse(file);
      } catch {
        exif = null;
      }
      setPreviewUrl(url);
      setMeta({ fileName: file.name, fileSize: file.size, width: img.width, height: img.height, type: file.type, exif });
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: file.name, sizeLabel: formatBytes(file.size) });
      setStatus('success');
    } catch {
      setErrorMsg('Could not read this image file.');
      setStatus('error');
    }
  }

  function downloadJson() {
    if (!meta) return;
    const json = JSON.stringify({ ...meta, exif: meta.exif ?? {} }, null, 2);
    downloadBlob(new Blob([json], { type: 'application/json' }), `${stripExtension(meta.fileName)}-metadata.json`);
  }

  function reset() {
    setMeta(null);
    setPreviewUrl('');
    setStatus('idle');
  }

  const exifEntries = meta?.exif ? Object.entries(meta.exif).filter(([, v]) => v !== undefined && v !== null && typeof v !== 'object') : [];

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/image-metadata-viewer" icon={Info} breadcrumb={{ label: 'Image Metadata Viewer' }} toolSlug={tool.slug}
    >
      <Card>
        {meta ? (
          <div className="grid sm:grid-cols-[200px_1fr] gap-6">
            <img src={previewUrl} alt={meta.fileName} className="w-full rounded-xl border border-navy-100 dark:border-white/10 object-cover aspect-square" />
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="font-semibold">{meta.fileName}</p>
                  <p className="text-sm text-navy-500 dark:text-ink-500">{formatBytes(meta.fileSize)} · {meta.width}×{meta.height}px · {meta.type}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" icon={<Download size={14} />} onClick={downloadJson}>Export JSON</Button>
                  <Button size="sm" variant="ghost" onClick={reset}>Reset</Button>
                </div>
              </div>

              {exifEntries.length === 0 ? (
                <SoftCard>
                  <p className="text-sm text-navy-500 dark:text-ink-500">No EXIF metadata found — this image may have been stripped of metadata, or the format doesn't support it (common for screenshots and web-optimized images).</p>
                </SoftCard>
              ) : (
                <div className="grid sm:grid-cols-2 gap-2 max-h-80 overflow-y-auto pr-1">
                  {exifEntries.map(([key, value]) => (
                    <div key={key} className="rounded-lg border border-navy-100 dark:border-white/10 px-3 py-2">
                      <p className="text-[11px] uppercase tracking-wide text-navy-400 dark:text-ink-500">{key}</p>
                      <p className="text-sm font-medium truncate">{String(value)}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <>
            <FileDropzone accept="image/*" label="Drop an image here" hint="Reads EXIF metadata if present" onFiles={handleFile} />
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : 'Reading metadata...'} />
            </div>
          </>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
