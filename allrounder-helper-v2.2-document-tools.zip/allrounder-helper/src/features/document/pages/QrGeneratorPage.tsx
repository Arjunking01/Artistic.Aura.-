import { useEffect, useState } from 'react';
import { QrCode } from 'lucide-react';
import QRCode from 'qrcode';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('qr-code-generator')!;

export default function QrGeneratorPage() {
  const [text, setText] = useState('https://allrounderhelper.com');
  const [size, setSize] = useState(320);
  const [darkColor, setDarkColor] = useState('#0a0e1a');
  const [lightColor, setLightColor] = useState('#ffffff');
  const [dataUrl, setDataUrl] = useState('');
  const [error, setError] = useState('');
  const { addEntry } = useToolHistory();

  useEffect(() => {
    if (!text.trim()) {
      setDataUrl('');
      return;
    }
    QRCode.toDataURL(text, { width: size, margin: 2, color: { dark: darkColor, light: lightColor } })
      .then((url: string) => {
        setDataUrl(url);
        setError('');
      })
      .catch(() => setError('Could not generate a QR code for this input.'));
  }, [text, size, darkColor, lightColor]);

  async function download() {
    if (!dataUrl) return;
    const blob = await (await fetch(dataUrl)).blob();
    downloadBlob(blob, 'qr-code.png');
    addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: 'qr-code.png', sizeLabel: formatBytes(blob.size) });
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/qr-code-generator" icon={QrCode} breadcrumb={{ label: 'QR Code Generator' }} toolSlug={tool.slug}
    >
      <Card>
        <div className="grid sm:grid-cols-[1fr_260px] gap-6">
          <div className="space-y-4">
            <label className="block text-sm font-medium text-navy-700 dark:text-ink-300">
              Text or URL
              <textarea value={text} onChange={(e) => setText(e.target.value)} rows={3} className="mt-1.5 w-full rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20" />
            </label>
            <label className="block text-sm">
              Size — {size}px
              <input type="range" min={128} max={512} step={16} value={size} onChange={(e) => setSize(Number(e.target.value))} className="mt-1 w-full accent-electric-500" />
            </label>
            <div className="grid grid-cols-2 gap-3">
              <label className="text-sm">
                Foreground
                <input type="color" value={darkColor} onChange={(e) => setDarkColor(e.target.value)} className="mt-1 h-10 w-full rounded-lg border border-navy-200 dark:border-white/10" />
              </label>
              <label className="text-sm">
                Background
                <input type="color" value={lightColor} onChange={(e) => setLightColor(e.target.value)} className="mt-1 h-10 w-full rounded-lg border border-navy-200 dark:border-white/10" />
              </label>
            </div>
            {error && <p className="text-sm text-red-500">{error}</p>}
            <Button disabled={!dataUrl} onClick={download}>Download PNG</Button>
          </div>

          <div className="flex items-center justify-center rounded-2xl border border-navy-100 dark:border-white/10 p-6 bg-white">
            {dataUrl ? <img src={dataUrl} alt="Generated QR code" className="max-w-full" /> : <p className="text-sm text-navy-400">Enter text to preview</p>}
          </div>
        </div>
      </Card>
    </DocumentToolLayout>
  );
}
