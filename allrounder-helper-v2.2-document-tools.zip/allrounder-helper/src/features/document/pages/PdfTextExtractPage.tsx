import { useState } from 'react';
import { FileText, Copy } from 'lucide-react';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob, stripExtension } from '../logic/fileUtils';
import { getPdfjs } from '../logic/pdfjsSetup';

const tool = getDocumentToolBySlug('pdf-to-text')!;

interface TextItemLike {
  str?: string;
}

export default function PdfTextExtractPage() {
  const [text, setText] = useState('');
  const [fileBaseName, setFileBaseName] = useState('document');
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const { addEntry } = useToolHistory();

  async function processFile(files: File[]) {
    const file = files[0];
    if (!file || file.type !== 'application/pdf') return;
    setStatus('processing');
    try {
      const bytes = await file.arrayBuffer();
      const pdfjs = getPdfjs();
      const doc = await pdfjs.getDocument({ data: bytes }).promise;
      let fullText = '';
      for (let i = 1; i <= doc.numPages; i++) {
        const page = await doc.getPage(i);
        const content = await page.getTextContent();
        const pageText = content.items.map((item) => (item as TextItemLike).str ?? '').join(' ');
        fullText += pageText + '\n\n';
      }
      setText(fullText.trim());
      setFileBaseName(stripExtension(file.name));
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: `${stripExtension(file.name)}.txt`, sizeLabel: formatBytes(new Blob([fullText]).size) });
      setStatus('success');
    } catch {
      setErrorMsg('Could not extract text. The PDF may be scanned (image-only) — try the OCR tool instead.');
      setStatus('error');
    }
  }

  function download() {
    downloadBlob(new Blob([text], { type: 'text/plain' }), `${fileBaseName}.txt`);
  }

  async function copyText() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  function reset() {
    setText('');
    setStatus('idle');
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/pdf-to-text" icon={FileText} breadcrumb={{ label: 'PDF to Text' }} toolSlug={tool.slug}
    >
      <Card>
        {text ? (
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm text-navy-600 dark:text-ink-300">Extracted {text.split(/\s+/).length.toLocaleString()} words</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" icon={<Copy size={14} />} onClick={copyText}>{copied ? 'Copied!' : 'Copy'}</Button>
                <Button size="sm" onClick={download}>Download .txt</Button>
                <Button size="sm" variant="ghost" onClick={reset}>Start over</Button>
              </div>
            </div>
            <textarea readOnly value={text} className="w-full h-96 rounded-xl border border-navy-100 dark:border-white/10 bg-navy-50/50 dark:bg-white/5 p-4 text-sm font-mono leading-relaxed outline-none resize-none" />
          </div>
        ) : (
          <>
            <FileDropzone accept="application/pdf" label="Drop a PDF here" hint="Extracts selectable text" onFiles={processFile} />
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : 'Extracting text...'} />
            </div>
          </>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
