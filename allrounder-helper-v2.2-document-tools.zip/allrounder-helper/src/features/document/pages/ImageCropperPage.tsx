import { useRef, useState } from 'react';
import { Crop } from 'lucide-react';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { DownloadCard } from '@/components/document/DownloadCard';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory, formatBytes } from '@/hooks/useToolHistory';
import { downloadBlob, loadImage, stripExtension } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('image-cropper')!;

interface Rect { x: number; y: number; w: number; h: number }

export default function ImageCropperPage() {
  const [file, setFile] = useState<File | null>(null);
  const [imgUrl, setImgUrl] = useState('');
  const [displaySize, setDisplaySize] = useState({ width: 0, height: 0 });
  const [naturalSize, setNaturalSize] = useState({ width: 0, height: 0 });
  const [selection, setSelection] = useState<Rect | null>(null);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [result, setResult] = useState<{ blob: Blob; name: string; previewUrl: string } | null>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const { addEntry } = useToolHistory();

  async function handleFile(files: File[]) {
    const f = files[0];
    if (!f || !f.type.startsWith('image/')) return;
    const url = URL.createObjectURL(f);
    try {
      const img = await loadImage(url);
      setFile(f);
      setImgUrl(url);
      setNaturalSize({ width: img.width, height: img.height });
      setSelection(null);
    } catch {
      setErrorMsg('Could not read this image.');
      setStatus('error');
    }
  }

  function pointerPos(e: React.PointerEvent) {
    const rect = imgRef.current!.getBoundingClientRect();
    return { x: Math.min(Math.max(0, e.clientX - rect.left), rect.width), y: Math.min(Math.max(0, e.clientY - rect.top), rect.height) };
  }

  function onPointerDown(e: React.PointerEvent) {
    const pos = pointerPos(e);
    setDragStart(pos);
    setSelection({ x: pos.x, y: pos.y, w: 0, h: 0 });
  }

  function onPointerMove(e: React.PointerEvent) {
    if (!dragStart) return;
    const pos = pointerPos(e);
    setSelection({
      x: Math.min(dragStart.x, pos.x),
      y: Math.min(dragStart.y, pos.y),
      w: Math.abs(pos.x - dragStart.x),
      h: Math.abs(pos.y - dragStart.y),
    });
  }

  function onPointerUp() {
    setDragStart(null);
  }

  async function crop() {
    if (!file || !selection || selection.w < 4 || selection.h < 4) {
      setErrorMsg('Drag a selection box on the image first.');
      setStatus('error');
      return;
    }
    setStatus('processing');
    try {
      const img = await loadImage(imgUrl);
      const scaleX = naturalSize.width / displaySize.width;
      const scaleY = naturalSize.height / displaySize.height;
      const sx = selection.x * scaleX;
      const sy = selection.y * scaleY;
      const sw = selection.w * scaleX;
      const sh = selection.h * scaleY;

      const canvas = document.createElement('canvas');
      canvas.width = sw;
      canvas.height = sh;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);

      const blob: Blob = await new Promise((resolve, reject) => {
        canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('encode failed'))), file.type.includes('png') ? 'image/png' : 'image/jpeg', 0.92);
      });

      const name = `${stripExtension(file.name)}-cropped.${file.type.includes('png') ? 'png' : 'jpg'}`;
      const previewUrl = URL.createObjectURL(blob);
      setResult({ blob, name, previewUrl });
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: name, sizeLabel: formatBytes(blob.size) });
      setStatus('success');
    } catch {
      setErrorMsg('Could not crop this image.');
      setStatus('error');
    }
  }

  function reset() {
    setFile(null);
    setImgUrl('');
    setSelection(null);
    setResult(null);
    setStatus('idle');
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/image-cropper" icon={Crop} breadcrumb={{ label: 'Image Cropper' }} toolSlug={tool.slug}
    >
      <Card>
        {result ? (
          <DownloadCard fileName={result.name} sizeLabel={formatBytes(result.blob.size)} previewUrl={result.previewUrl} onDownload={() => downloadBlob(result.blob, result.name)} onReset={reset} />
        ) : !file ? (
          <>
            <FileDropzone accept="image/*" label="Drop an image here" hint="Drag to select a crop area" onFiles={handleFile} />
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : undefined} />
            </div>
          </>
        ) : (
          <div>
            <p className="text-sm text-navy-500 dark:text-ink-500 mb-3">Drag on the image to select the area you want to keep.</p>
            <div
              className="relative inline-block touch-none select-none cursor-crosshair max-w-full"
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
            >
              <img
                ref={imgRef}
                src={imgUrl}
                alt="Crop source"
                onLoad={(e) => setDisplaySize({ width: e.currentTarget.width, height: e.currentTarget.height })}
                className="max-w-full rounded-xl border border-navy-100 dark:border-white/10 block"
                draggable={false}
              />
              {selection && (
                <div
                  className="absolute border-2 border-electric-500 bg-electric-500/10"
                  style={{ left: selection.x, top: selection.y, width: selection.w, height: selection.h }}
                />
              )}
            </div>
            <div className="flex items-center gap-3 mt-5">
              <Button onClick={crop}>Crop image</Button>
              <Button variant="ghost" onClick={reset}>Choose another</Button>
            </div>
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : undefined} />
            </div>
          </div>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
