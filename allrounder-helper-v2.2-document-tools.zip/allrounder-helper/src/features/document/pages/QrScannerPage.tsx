import { useEffect, useRef, useState } from 'react';
import { ScanLine, Camera, CameraOff, Copy } from 'lucide-react';
import jsQR from 'jsqr';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory } from '@/hooks/useToolHistory';
import { loadImage } from '../logic/fileUtils';

const tool = getDocumentToolBySlug('qr-code-scanner')!;

export default function QrScannerPage() {
  const [result, setResult] = useState('');
  const [error, setError] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [copied, setCopied] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const { addEntry } = useToolHistory();

  function stopCamera() {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraActive(false);
  }

  useEffect(() => () => stopCamera(), []);

  async function startCamera() {
    setError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraActive(true);
      scanLoop();
    } catch {
      setError('Could not access the camera. Check browser permissions, or upload an image instead.');
    }
  }

  function scanLoop() {
    const video = videoRef.current;
    if (!video || video.readyState !== video.HAVE_ENOUGH_DATA) {
      rafRef.current = requestAnimationFrame(scanLoop);
      return;
    }
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(video, 0, 0);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height);
    if (code?.data) {
      setResult(code.data);
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: code.data.slice(0, 40), sizeLabel: 'Scanned' });
      stopCamera();
      return;
    }
    rafRef.current = requestAnimationFrame(scanLoop);
  }

  async function handleFile(files: File[]) {
    const file = files[0];
    if (!file || !file.type.startsWith('image/')) return;
    setError('');
    try {
      const url = URL.createObjectURL(file);
      const img = await loadImage(url);
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      if (code?.data) {
        setResult(code.data);
        addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: code.data.slice(0, 40), sizeLabel: 'Scanned' });
      } else {
        setError('No QR code detected in this image. Try a clearer or closer photo.');
      }
    } catch {
      setError('Could not read this image file.');
    }
  }

  async function copyResult() {
    await navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/qr-code-scanner" icon={ScanLine} breadcrumb={{ label: 'QR Code Scanner' }} toolSlug={tool.slug}
    >
      <Card>
        {result ? (
          <SoftCard className="space-y-3">
            <p className="text-sm text-navy-500 dark:text-ink-500">Scanned content</p>
            <p className="font-medium break-all">{result}</p>
            <div className="flex gap-2">
              <Button size="sm" icon={<Copy size={14} />} onClick={copyResult}>{copied ? 'Copied!' : 'Copy'}</Button>
              <Button size="sm" variant="ghost" onClick={() => setResult('')}>Scan another</Button>
            </div>
          </SoftCard>
        ) : (
          <div className="space-y-5">
            <div className="flex items-center gap-3">
              {!cameraActive ? (
                <Button icon={<Camera size={16} />} onClick={startCamera}>Use camera</Button>
              ) : (
                <Button variant="outline" icon={<CameraOff size={16} />} onClick={stopCamera}>Stop camera</Button>
              )}
            </div>

            {cameraActive && (
              <video ref={videoRef} className="w-full max-w-sm rounded-2xl border border-navy-100 dark:border-white/10" muted playsInline />
            )}

            <FileDropzone accept="image/*" label="Or drop a QR code image here" onFiles={handleFile} />
            {error && <p className="text-sm text-red-500">{error}</p>}
          </div>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
