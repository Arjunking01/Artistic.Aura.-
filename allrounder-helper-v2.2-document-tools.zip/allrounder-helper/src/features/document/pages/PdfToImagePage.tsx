import { useState } from 'react';
import { ImageDown } from 'lucide-react';
import JSZip from 'jszip';
import { DocumentToolLayout } from '@/components/DocumentToolLayout';
import { Card } from '@/components/ui/Card';
import { FileDropzone } from '@/components/document/FileDropzone';
import { ProcessingIndicator } from '@/components/document/ProcessingIndicator';
import { Button } from '@/components/ui/Button';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';
import { useToolHistory } from '@/hooks/useToolHistory';
import { downloadBlob, stripExtension } from '../logic/fileUtils';
import { getPdfjs } from '../logic/pdfjsSetup';

const tool = getDocumentToolBySlug('pdf-to-image')!;

export default function PdfToImagePage() {
  const [images, setImages] = useState<{ url: string; name: string }[]>([]);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const { addEntry } = useToolHistory();

  async function processFile(files: File[]) {
    const file = files[0];
    if (!file || file.type !== 'application/pdf') return;
    setStatus('processing');
    try {
      const bytes = await file.arrayBuffer();
      const pdfjs = getPdfjs();
      const doc = await pdfjs.getDocument({ data: bytes }).promise;
      const baseName = stripExtension(file.name);
      const rendered: { url: string; name: string }[] = [];

      for (let i = 1; i <= doc.numPages; i++) {
        const page = await doc.getPage(i);
        const viewport = page.getViewport({ scale: 2 });
        const canvas = document.createElement('canvas');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext('2d')!;
        await page.render({ canvasContext: ctx, viewport, canvas }).promise;
        rendered.push({ url: canvas.toDataURL('image/png'), name: `${baseName}-page-${i}.png` });
      }

      setImages(rendered);
      addEntry({ tool: tool.name, toolSlug: tool.slug, fileName: `${baseName} (${rendered.length} pages)`, sizeLabel: `${rendered.length} PNG` });
      setStatus('success');
    } catch {
      setErrorMsg('Could not render this PDF. It may be encrypted or corrupted.');
      setStatus('error');
    }
  }

  function downloadOne(img: { url: string; name: string }) {
    fetch(img.url).then((r) => r.blob()).then((blob) => downloadBlob(blob, img.name));
  }

  async function downloadAll() {
    const zip = new JSZip();
    for (const img of images) {
      const blob = await (await fetch(img.url)).blob();
      zip.file(img.name, blob);
    }
    const zipBlob = await zip.generateAsync({ type: 'blob' });
    downloadBlob(zipBlob, 'pdf-pages.zip');
  }

  function reset() {
    setImages([]);
    setStatus('idle');
  }

  return (
    <DocumentToolLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/pdf-to-image" icon={ImageDown} breadcrumb={{ label: 'PDF to Image' }} toolSlug={tool.slug}
    >
      <Card>
        {images.length > 0 ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-navy-600 dark:text-ink-300">{images.length} page{images.length !== 1 ? 's' : ''} rendered</p>
              <div className="flex gap-2">
                {images.length > 1 && <Button size="sm" onClick={downloadAll}>Download all (ZIP)</Button>}
                <Button size="sm" variant="ghost" onClick={reset}>Start over</Button>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {images.map((img) => (
                <button key={img.name} onClick={() => downloadOne(img)} className="group rounded-xl border border-navy-100 dark:border-white/10 p-2 text-left hover:border-electric-500 transition-colors">
                  <img src={img.url} alt={img.name} className="w-full rounded-lg" />
                  <p className="text-xs text-navy-500 dark:text-ink-500 mt-1.5 truncate group-hover:text-electric-500">{img.name}</p>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            <FileDropzone accept="application/pdf" label="Drop a PDF here" hint="Renders every page as a PNG" onFiles={processFile} />
            <div className="mt-4">
              <ProcessingIndicator status={status} message={status === 'error' ? errorMsg : 'Rendering pages...'} />
            </div>
          </>
        )}
      </Card>
    </DocumentToolLayout>
  );
}
