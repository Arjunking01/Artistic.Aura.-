import { Layers } from 'lucide-react';
import { ImageTransformWorkspace } from '../components/ImageTransformWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('image-resizer')!;

export default function ImageResizerPage() {
  return (
    <ImageTransformWorkspace
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/image-resizer" icon={Layers} breadcrumb={{ label: 'Image Resizer' }} toolSlug={tool.slug}
      formatOptions="same-as-source"
      allowResize
      allowQuality
      defaultQuality={0.92}
    />
  );
}
