import { FileImage } from 'lucide-react';
import { ImageTransformWorkspace } from '../components/ImageTransformWorkspace';
import { getDocumentToolBySlug } from '@/data/documentToolsRegistry';

const tool = getDocumentToolBySlug('webp-converter')!;

export default function WebpConverterPage() {
  return (
    <ImageTransformWorkspace
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/document-tools/webp-converter" icon={FileImage} breadcrumb={{ label: 'WEBP Converter' }} toolSlug={tool.slug}
      formatOptions={['image/webp', 'image/jpeg', 'image/png']}
      allowQuality
    />
  );
}
