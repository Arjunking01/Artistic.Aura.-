import { useMemo, useState } from 'react';
import { CalendarCheck } from 'lucide-react';
import { CalculatorLayout } from '@/components/CalculatorLayout';
import { Card } from '@/components/ui/Card';
import { NumberField } from '@/components/ui/Field';
import { ResultStat } from '@/components/ui/ResultStat';
import { calculateAttendance } from '../logic/calculations';
import { getToolBySlug } from '@/data/toolsRegistry';

const tool = getToolBySlug('attendance-calculator')!;

export default function AttendanceCalculatorPage() {
  const [attended, setAttended] = useState('');
  const [total, setTotal] = useState('');
  const [target, setTarget] = useState('75');

  const result = useMemo(
    () => calculateAttendance(parseFloat(attended), parseFloat(total), parseFloat(target)),
    [attended, total, target]
  );

  return (
    <CalculatorLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/academic-tools/attendance-calculator" icon={CalendarCheck}
      breadcrumb={{ label: 'Attendance Calculator' }} article={article}
    >
      <Card>
        <div className="grid sm:grid-cols-3 gap-4">
          <NumberField id="attended" label="Classes attended" placeholder="e.g. 42" value={attended} onChange={(e) => setAttended(e.target.value)} />
          <NumberField id="total" label="Total classes held" placeholder="e.g. 50" value={total} onChange={(e) => setTotal(e.target.value)} />
          <NumberField id="target" label="Target attendance" suffix="%" value={target} onChange={(e) => setTarget(e.target.value)} />
        </div>
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-6 border-t border-navy-100 dark:border-white/10 pt-6">
          <ResultStat label="Current attendance" value={`${result.currentPercent.toFixed(2)}%`} />
          <ResultStat label="Classes you can miss" value={String(result.canMiss)} tone="emerald" />
          <ResultStat label="Classes you must attend" value={String(result.needToAttend)} tone="violet" />
        </div>
      </Card>
    </CalculatorLayout>
  );
}

const article = {
  intro: 'This calculator turns your attended and total class counts into a live attendance percentage, then works out how much slack you have — or how much ground you need to make up — against a target percentage.',
  whyItMatters: 'Most institutions set a minimum attendance requirement to sit exams. Knowing your safe margin in advance means you can plan absences deliberately instead of finding out too late that you fell short.',
  howItWorks: [
    'Enter how many classes you have attended so far.',
    'Enter the total number of classes held so far.',
    'Set your target attendance percentage (commonly 75%).',
    'The tool calculates your current percentage plus how many classes you can miss or must attend to stay on target.',
  ],
  examples: [
    { title: 'Safely below target', body: 'Attended 45 of 50 classes (90%) with a 75% target — you can miss several upcoming classes and still clear the bar.' },
    { title: 'Below target', body: 'Attended 30 of 50 classes (60%) with a 75% target — the calculator shows exactly how many consecutive classes you must attend to recover.' },
  ],
  mistakes: [
    'Forgetting to update the total class count as the term progresses, which understates how many you can still miss.',
    'Setting an unrealistic target percentage that doesn\'t match your institution\'s actual policy.',
    'Assuming missed classes can be "made up" without checking your institution\'s specific rules on condonation or medical leave.',
  ],
  tips: [
    'Recalculate weekly so your safe-miss count always reflects the latest data.',
    'If you are below target, prioritise attending every class until the required-attendance count reaches zero.',
    'Check whether your institution counts attendance per subject or as an overall average — enter figures accordingly.',
  ],
  faqs: [
    { question: 'How is the "classes you can miss" number calculated?', answer: 'It finds the maximum total class count at which your current attended count still meets the target percentage, then subtracts classes held so far.' },
    { question: 'What if my attendance is already below target?', answer: 'The calculator shows 0 for classes you can miss and instead reports how many consecutive classes you need to attend to reach your target.' },
    { question: 'Does this account for future classes?', answer: 'It projects forward assuming you attend every future class in the "need to attend" scenario, so recalculate as new classes are held.' },
  ],
  related: [
    { label: 'Deadline Calculator', href: '/academic-tools/deadline-calculator' },
    { label: 'Study Hours Calculator', href: '/academic-tools/study-hours-calculator' },
  ],
};
