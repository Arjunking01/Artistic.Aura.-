import { useMemo, useState } from 'react';
import { ClipboardCheck } from 'lucide-react';
import { CalculatorLayout } from '@/components/CalculatorLayout';
import { Card } from '@/components/ui/Card';
import { NumberField } from '@/components/ui/Field';
import { ResultStat } from '@/components/ui/ResultStat';
import { calculateMarksRequired } from '../logic/calculations';
import { getToolBySlug } from '@/data/toolsRegistry';

const tool = getToolBySlug('marks-required-calculator')!;

export default function MarksRequiredPage() {
  const [current, setCurrent] = useState('');
  const [total, setTotal] = useState('');
  const [target, setTarget] = useState('');
  const valid = current !== '' && total !== '' && parseFloat(total) > 0;
  const result = useMemo(
    () => (valid ? calculateMarksRequired(parseFloat(current), parseFloat(total), target === '' ? null : parseFloat(target)) : null),
    [current, total, target, valid]
  );

  return (
    <CalculatorLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/academic-tools/marks-required-calculator" icon={ClipboardCheck}
      breadcrumb={{ label: 'Marks Required Calculator' }} article={article}
    >
      <Card>
        <div className="grid sm:grid-cols-3 gap-4">
          <NumberField id="current" label="Current marks" value={current} onChange={(e) => setCurrent(e.target.value)} />
          <NumberField id="total" label="Total marks" value={total} onChange={(e) => setTotal(e.target.value)} />
          <NumberField id="target" label="Target percentage (optional)" suffix="%" value={target} onChange={(e) => setTarget(e.target.value)} />
        </div>
        <div className="mt-8 grid sm:grid-cols-3 gap-6 border-t border-navy-100 dark:border-white/10 pt-6">
          <ResultStat label="Current percentage" value={result ? `${result.currentPercentage.toFixed(2)}%` : '—'} />
          <ResultStat label="Marks needed for target" value={result?.requiredMarks !== null && result ? String(result.requiredMarks) : '—'} tone="violet" />
          <ResultStat label="Status" value={result ? result.status : '—'} tone={result?.status === 'Pass' ? 'emerald' : 'brand'} />
        </div>
      </Card>
    </CalculatorLayout>
  );
}

const article = {
  intro: 'This calculator shows your current percentage from marks obtained so far, and — if you set a target percentage — exactly how many total marks you need to reach it.',
  whyItMatters: 'Knowing the precise mark threshold for a target grade turns a vague goal like "do better" into a concrete number you can plan revision and remaining assessments around.',
  howItWorks: [
    'Enter the marks you have obtained so far.',
    'Enter the total marks the assessment (or course) is out of.',
    'Optionally set a target percentage you want to reach.',
    'The tool calculates your current percentage and the total marks needed to hit your target.',
  ],
  examples: [
    { title: 'On track', body: 'Current 320/400 = 80%. Target 75% needs only 300 marks — already achieved.' },
    { title: 'Needs more', body: 'Current 150/400 = 37.5%. Target 60% needs 240 marks — 90 more than currently earned.' },
  ],
  mistakes: [
    'Using marks from a single test as "current" when the target percentage refers to the full course total.',
    'Forgetting that required marks are a total figure, not additional marks needed beyond what you already have.',
    'Setting a target below 40%, which may not reflect your institution\'s actual pass threshold.',
  ],
  tips: [
    'Recalculate after every assessment to keep your target on track.',
    'Use the pass/fail status as a quick sanity check alongside the more specific target-percentage figure.',
    'Combine with the Exam Score Calculator to plan for a single upcoming exam specifically.',
  ],
  faqs: [
    { question: 'Is 40% always the pass mark?', answer: 'The calculator uses 40% as a common default, but pass marks vary by institution and course — check your specific requirement.' },
    { question: 'What does "marks needed for target" mean exactly?', answer: 'It is the total marks (out of your total marks field) required to reach the target percentage — not additional marks on top of your current score.' },
    { question: 'Can target percentage be left blank?', answer: 'Yes — leaving it blank only shows your current percentage and pass/fail status.' },
  ],
  related: [
    { label: 'Percentage Calculator', href: '/academic-tools/percentage-calculator' },
    { label: 'Exam Score Calculator', href: '/academic-tools/exam-score-calculator' },
    { label: 'Assignment Score Calculator', href: '/academic-tools/assignment-score-calculator' },
  ],
};
