import { useState } from 'react';
import { Calculator, Delete } from 'lucide-react';
import { CalculatorLayout } from '@/components/CalculatorLayout';
import { Card } from '@/components/ui/Card';
import { evaluateScientificExpression } from '../logic/calculations';
import { getToolBySlug } from '@/data/toolsRegistry';

const tool = getToolBySlug('scientific-calculator')!;

const KEYS: string[] = [
  '(', ')', '√', '^',
  '7', '8', '9', '/',
  '4', '5', '6', '*',
  '1', '2', '3', '-',
  '0', '.', 'π', '+',
];

export default function ScientificCalculatorPage() {
  const [expression, setExpression] = useState('');
  const [result, setResult] = useState<string>('');
  const [error, setError] = useState(false);

  function press(key: string) {
    setExpression((prev) => prev + key);
  }

  function evaluate() {
    try {
      const value = evaluateScientificExpression(expression);
      setResult(String(Math.round(value * 1e10) / 1e10));
      setError(false);
    } catch {
      setResult('Error');
      setError(true);
    }
  }

  function clearAll() {
    setExpression('');
    setResult('');
    setError(false);
  }

  function backspace() {
    setExpression((prev) => prev.slice(0, -1));
  }

  return (
    <CalculatorLayout
      toolName={tool.name} tagline={tool.tagline} description={tool.description}
      path="/academic-tools/scientific-calculator" icon={Calculator}
      breadcrumb={{ label: 'Scientific Calculator' }} article={article}
    >
      <Card className="max-w-md">
        <div className="rounded-2xl bg-navy-900 dark:bg-black/40 p-5 mb-5 text-right">
          <p className="text-navy-400 text-sm font-mono min-h-[1.25rem] break-all">{expression || '0'}</p>
          <p className={`text-3xl font-mono font-semibold mt-1 break-all ${error ? 'text-red-400' : 'text-white'}`}>
            {result || '\u00A0'}
          </p>
        </div>

        <div className="grid grid-cols-4 gap-2 mb-2">
          <button onClick={clearAll} className="col-span-2 rounded-xl bg-red-500/10 text-red-500 font-semibold py-3 hover:bg-red-500/20 transition-colors">AC</button>
          <button onClick={backspace} className="flex items-center justify-center rounded-xl bg-navy-100 dark:bg-white/10 py-3 hover:bg-navy-200 dark:hover:bg-white/20 transition-colors">
            <Delete size={16} />
          </button>
          <button onClick={evaluate} className="rounded-xl gradient-brand text-white font-semibold py-3">=</button>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {KEYS.map((key) => (
            <button
              key={key}
              onClick={() => press(key)}
              className="rounded-xl border border-navy-200 dark:border-white/10 py-3 font-medium hover:border-electric-500 hover:text-electric-500 transition-colors"
            >
              {key}
            </button>
          ))}
        </div>
      </Card>
    </CalculatorLayout>
  );
}

const article = {
  intro: 'A browser-based scientific calculator that supports standard arithmetic, parentheses, square roots, powers, and the constant π — enough for everyday coursework without installing anything.',
  whyItMatters: 'A quick, always-available calculator saves time during homework, lab reports, or exam revision, especially on a phone where a physical calculator isn\'t always at hand.',
  howItWorks: [
    'Tap number and operator keys to build an expression.',
    'Use √ for square root and ^ for powers.',
    'Press = to evaluate the expression.',
    'Use the delete key to remove the last character, or AC to clear everything.',
  ],
  examples: [
    { title: 'Powers', body: '2^10 evaluates to 1024.' },
    { title: 'Roots and parentheses', body: '√(64) evaluates to 8, and (3+2)*4 evaluates to 20.' },
  ],
  mistakes: [
    'Leaving a parenthesis unclosed, which the calculator will flag as an error.',
    'Chaining operators without a number between them, e.g. "5*+2".',
    'Expecting memory or graphing functions — this tool covers standard scientific operations only.',
  ],
  tips: [
    'Use π directly in expressions, e.g. "2*π" for circumference-style calculations.',
    'Build long expressions in one go rather than evaluating after every step, to avoid losing precision from rounding.',
    'Use the backspace key to correct a single mistyped character instead of clearing everything.',
  ],
  faqs: [
    { question: 'Does this calculator support trigonometric functions?', answer: 'The current version covers arithmetic, powers, roots, and π. Trigonometric functions are planned for a future update.' },
    { question: 'Is my calculation history saved?', answer: 'Not currently — each session starts fresh. Use the Notes tool once available to save calculations you want to keep.' },
    { question: 'Why do I see "Error"?', answer: 'This usually means the expression is incomplete or invalid, such as an unmatched parenthesis or a division by zero.' },
  ],
  related: [
    { label: 'Unit Converter', href: '/academic-tools/unit-converter' },
    { label: 'Percentage Calculator', href: '/academic-tools/percentage-calculator' },
  ],
};
