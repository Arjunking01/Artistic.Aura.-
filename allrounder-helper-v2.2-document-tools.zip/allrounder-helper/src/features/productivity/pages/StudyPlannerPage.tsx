import { useState } from 'react';
import { CalendarRange, Plus, Trash2 } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import {
  DAYS, SUBJECT_COLORS,
  type Subject, type StudySession, type ExamPlan, type StudyGoal,
} from '../logic/studyPlannerTypes';

const tool = getProductivityToolBySlug('study-planner')!;

export default function StudyPlannerPage() {
  const [subjects, setSubjects] = useLocalStorage<Subject[]>('ar-study-subjects', []);
  const [sessions, setSessions] = useLocalStorage<StudySession[]>('ar-study-sessions', []);
  const [exams, setExams] = useLocalStorage<ExamPlan[]>('ar-study-exams', []);
  const [goals, setGoals] = useLocalStorage<StudyGoal[]>('ar-study-goals', []);

  const [subjectName, setSubjectName] = useState('');
  const [sessionDraft, setSessionDraft] = useState({ subjectId: '', day: 'Mon', startTime: '16:00', endTime: '17:00' });
  const [examDraft, setExamDraft] = useState({ subjectId: '', date: '', notes: '' });
  const [goalText, setGoalText] = useState('');

  function addSubject() {
    if (!subjectName.trim()) return;
    const subject: Subject = {
      id: crypto.randomUUID(),
      name: subjectName.trim(),
      color: SUBJECT_COLORS[subjects.length % SUBJECT_COLORS.length],
      progress: 0,
    };
    setSubjects((prev) => [...prev, subject]);
    setSubjectName('');
  }

  function removeSubject(id: string) {
    setSubjects((prev) => prev.filter((s) => s.id !== id));
    setSessions((prev) => prev.filter((s) => s.subjectId !== id));
    setExams((prev) => prev.filter((e) => e.subjectId !== id));
  }

  function updateProgress(id: string, progress: number) {
    setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, progress } : s)));
  }

  function addSession() {
    if (!sessionDraft.subjectId) return;
    setSessions((prev) => [...prev, { id: crypto.randomUUID(), ...sessionDraft }]);
  }

  function addExam() {
    if (!examDraft.subjectId || !examDraft.date) return;
    setExams((prev) => [...prev, { id: crypto.randomUUID(), ...examDraft }].sort((a, b) => a.date.localeCompare(b.date)));
    setExamDraft({ subjectId: '', date: '', notes: '' });
  }

  function addGoal() {
    if (!goalText.trim()) return;
    setGoals((prev) => [...prev, { id: crypto.randomUUID(), text: goalText.trim(), done: false }]);
    setGoalText('');
  }

  const subjectById = (id: string) => subjects.find((s) => s.id === id);

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/study-planner"
      icon={CalendarRange}
      breadcrumb={{ label: 'Study Planner' }}
    >
      <div className="space-y-6">
        {/* Subjects */}
        <Card>
          <h2 className="font-semibold text-lg mb-4">Subjects & progress</h2>
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              placeholder="Add a subject, e.g. Organic Chemistry"
              value={subjectName}
              onChange={(e) => setSubjectName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addSubject()}
              className="flex-1 rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20"
            />
            <Button icon={<Plus size={16} />} onClick={addSubject}>Add</Button>
          </div>

          {subjects.length === 0 ? (
            <EmptyState icon={CalendarRange} title="No subjects yet" description="Add your first subject to start planning sessions and exams." />
          ) : (
            <div className="grid sm:grid-cols-2 gap-3">
              {subjects.map((s) => (
                <SoftCard key={s.id} className="flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                      <span className="font-medium">{s.name}</span>
                    </div>
                    <button onClick={() => removeSubject(s.id)} aria-label="Remove subject" className="text-navy-400 hover:text-red-500">
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <input
                    type="range" min={0} max={100} value={s.progress}
                    onChange={(e) => updateProgress(s.id, Number(e.target.value))}
                    className="w-full accent-electric-500"
                  />
                  <span className="text-xs text-navy-500 dark:text-ink-500">{s.progress}% covered</span>
                </SoftCard>
              ))}
            </div>
          )}
        </Card>

        {/* Weekly schedule */}
        <Card>
          <h2 className="font-semibold text-lg mb-4">Weekly schedule</h2>
          {subjects.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-5">
              <select value={sessionDraft.subjectId} onChange={(e) => setSessionDraft((d) => ({ ...d, subjectId: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 text-sm outline-none focus:border-electric-500">
                <option value="">Subject</option>
                {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <select value={sessionDraft.day} onChange={(e) => setSessionDraft((d) => ({ ...d, day: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 text-sm outline-none focus:border-electric-500">
                {DAYS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
              <input type="time" value={sessionDraft.startTime} onChange={(e) => setSessionDraft((d) => ({ ...d, startTime: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 text-sm outline-none focus:border-electric-500" />
              <input type="time" value={sessionDraft.endTime} onChange={(e) => setSessionDraft((d) => ({ ...d, endTime: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 text-sm outline-none focus:border-electric-500" />
              <Button size="sm" icon={<Plus size={14} />} onClick={addSession}>Add session</Button>
            </div>
          )}

          <div className="grid grid-cols-7 gap-2 text-xs">
            {DAYS.map((day) => (
              <div key={day} className="space-y-1.5">
                <p className="font-semibold text-center text-navy-500 dark:text-ink-400 mb-1">{day}</p>
                {sessions.filter((s) => s.day === day).map((s) => {
                  const subj = subjectById(s.subjectId);
                  return (
                    <div key={s.id} className="rounded-lg px-2 py-1.5 text-white text-[10px] leading-tight" style={{ background: subj?.color ?? '#8b3ffb' }}>
                      <p className="font-medium truncate">{subj?.name ?? 'Subject'}</p>
                      <p className="opacity-80">{s.startTime}–{s.endTime}</p>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </Card>

        {/* Exam planning */}
        <Card>
          <h2 className="font-semibold text-lg mb-4">Exam planning</h2>
          {subjects.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-5">
              <select value={examDraft.subjectId} onChange={(e) => setExamDraft((d) => ({ ...d, subjectId: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 text-sm outline-none focus:border-electric-500">
                <option value="">Subject</option>
                {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <input type="date" value={examDraft.date} onChange={(e) => setExamDraft((d) => ({ ...d, date: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 text-sm outline-none focus:border-electric-500" />
              <input type="text" placeholder="Notes" value={examDraft.notes} onChange={(e) => setExamDraft((d) => ({ ...d, notes: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 text-sm outline-none focus:border-electric-500 flex-1 min-w-[140px]" />
              <Button size="sm" icon={<Plus size={14} />} onClick={addExam}>Add exam</Button>
            </div>
          )}
          {exams.length === 0 ? (
            <EmptyState icon={CalendarRange} title="No exams planned" description="Add an exam date to see it counted down here." />
          ) : (
            <ul className="space-y-2">
              {exams.map((e) => (
                <li key={e.id} className="flex items-center justify-between rounded-xl border border-navy-100 dark:border-white/10 px-4 py-3">
                  <div>
                    <p className="font-medium text-sm">{subjectById(e.subjectId)?.name ?? 'Subject'}</p>
                    <p className="text-xs text-navy-500 dark:text-ink-500">{new Date(e.date).toLocaleDateString()} {e.notes && `· ${e.notes}`}</p>
                  </div>
                  <button onClick={() => setExams((prev) => prev.filter((x) => x.id !== e.id))} aria-label="Remove exam" className="text-navy-400 hover:text-red-500">
                    <Trash2 size={14} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Study goals */}
        <Card>
          <h2 className="font-semibold text-lg mb-4">Study goals</h2>
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              placeholder="Add a study goal..."
              value={goalText}
              onChange={(e) => setGoalText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addGoal()}
              className="flex-1 rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20"
            />
            <Button size="sm" icon={<Plus size={14} />} onClick={addGoal}>Add</Button>
          </div>
          {goals.length === 0 ? (
            <EmptyState icon={CalendarRange} title="No goals set" description="Add a study goal to track alongside your schedule." />
          ) : (
            <ul className="space-y-2">
              {goals.map((g) => (
                <li key={g.id} className="flex items-center gap-3 rounded-xl border border-navy-100 dark:border-white/10 px-4 py-2.5">
                  <input
                    type="checkbox"
                    checked={g.done}
                    onChange={() => setGoals((prev) => prev.map((x) => (x.id === g.id ? { ...x, done: !x.done } : x)))}
                    className="h-4 w-4 accent-electric-500"
                  />
                  <span className={g.done ? 'line-through text-navy-400 dark:text-ink-500 flex-1' : 'flex-1'}>{g.text}</span>
                  <button onClick={() => setGoals((prev) => prev.filter((x) => x.id !== g.id))} aria-label="Remove goal" className="text-navy-400 hover:text-red-500">
                    <Trash2 size={14} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </ProductivityToolLayout>
  );
}
