import { useMemo, useState } from 'react';
import { CheckSquare, Plus, Trash2, Pencil, Search, X } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { clsx } from '@/lib/utils/clsx';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import { DEFAULT_CATEGORIES, type Task, type TaskPriority } from '../logic/todoTypes';

const tool = getProductivityToolBySlug('todo-list')!;
type Filter = 'all' | 'active' | 'completed';

const PRIORITY_STYLES: Record<TaskPriority, string> = {
  low: 'bg-emerald-500/10 text-emerald-500',
  medium: 'bg-violet-500/10 text-violet-500',
  high: 'bg-red-500/10 text-red-500',
};

function emptyDraft(): Omit<Task, 'id' | 'createdAt' | 'completed'> {
  return { title: '', notes: '', category: DEFAULT_CATEGORIES[0], priority: 'medium', dueDate: '' };
}

export default function TodoListPage() {
  const [tasks, setTasks] = useLocalStorage<Task[]>('ar-todo-tasks', []);
  const [filter, setFilter] = useState<Filter>('all');
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState(emptyDraft());
  const [formOpen, setFormOpen] = useState(false);

  const filtered = useMemo(() => {
    return tasks
      .filter((t) => (filter === 'active' ? !t.completed : filter === 'completed' ? t.completed : true))
      .filter((t) => t.title.toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999'));
  }, [tasks, filter, search]);

  function openNewForm() {
    setEditingId(null);
    setDraft(emptyDraft());
    setFormOpen(true);
  }

  function openEditForm(task: Task) {
    setEditingId(task.id);
    setDraft({ title: task.title, notes: task.notes ?? '', category: task.category, priority: task.priority, dueDate: task.dueDate ?? '' });
    setFormOpen(true);
  }

  function saveTask() {
    if (!draft.title.trim()) return;
    if (editingId) {
      setTasks((prev) => prev.map((t) => (t.id === editingId ? { ...t, ...draft, title: draft.title.trim() } : t)));
    } else {
      const newTask: Task = { id: crypto.randomUUID(), createdAt: new Date().toISOString(), completed: false, ...draft, title: draft.title.trim() };
      setTasks((prev) => [newTask, ...prev]);
    }
    setFormOpen(false);
    setEditingId(null);
    setDraft(emptyDraft());
  }

  function toggleComplete(id: string) {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  }

  function deleteTask(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }

  const activeCount = tasks.filter((t) => !t.completed).length;

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/todo-list"
      icon={CheckSquare}
      breadcrumb={{ label: 'To-Do List' }}
      headerActions={<Button icon={<Plus size={16} />} onClick={openNewForm}>New task</Button>}
    >
      <Card>
        <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-5">
          <div className="flex gap-1 rounded-xl bg-navy-50 dark:bg-white/5 p-1 w-fit">
            {(['all', 'active', 'completed'] as Filter[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={clsx(
                  'px-3.5 py-1.5 rounded-lg text-sm font-medium capitalize transition-colors',
                  filter === f ? 'bg-white dark:bg-navy-800 text-electric-500 shadow-sm' : 'text-navy-500 dark:text-ink-400'
                )}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="relative">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              type="text"
              placeholder="Search tasks..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 pl-9 pr-4 py-2 text-sm outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20 w-full sm:w-56"
            />
          </div>
        </div>

        {formOpen && (
          <SoftCard className="mb-5">
            <div className="grid sm:grid-cols-2 gap-3">
              <input
                autoFocus
                type="text"
                placeholder="Task title"
                value={draft.title}
                onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
                className="sm:col-span-2 rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20"
              />
              <select
                value={draft.category}
                onChange={(e) => setDraft((d) => ({ ...d, category: e.target.value }))}
                className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500"
              >
                {DEFAULT_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <select
                value={draft.priority}
                onChange={(e) => setDraft((d) => ({ ...d, priority: e.target.value as TaskPriority }))}
                className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500"
              >
                <option value="low">Low priority</option>
                <option value="medium">Medium priority</option>
                <option value="high">High priority</option>
              </select>
              <input
                type="date"
                value={draft.dueDate}
                onChange={(e) => setDraft((d) => ({ ...d, dueDate: e.target.value }))}
                className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500"
              />
              <input
                type="text"
                placeholder="Notes (optional)"
                value={draft.notes}
                onChange={(e) => setDraft((d) => ({ ...d, notes: e.target.value }))}
                className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500"
              />
            </div>
            <div className="flex gap-2 mt-4">
              <Button size="sm" onClick={saveTask}>{editingId ? 'Save changes' : 'Add task'}</Button>
              <Button size="sm" variant="ghost" onClick={() => { setFormOpen(false); setEditingId(null); }}>Cancel</Button>
            </div>
          </SoftCard>
        )}

        {filtered.length === 0 ? (
          <EmptyState icon={CheckSquare} title="No tasks here yet" description="Add a task to start tracking your to-dos with due dates and priorities." />
        ) : (
          <ul className="space-y-2">
            {filtered.map((task) => (
              <li
                key={task.id}
                className="flex items-start gap-3 rounded-xl border border-navy-100 dark:border-white/10 p-3.5 group"
              >
                <button
                  onClick={() => toggleComplete(task.id)}
                  aria-label={task.completed ? 'Mark as active' : 'Mark as complete'}
                  className={clsx(
                    'mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 transition-colors',
                    task.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-navy-300 dark:border-white/20'
                  )}
                >
                  {task.completed && <CheckSquare size={12} />}
                </button>
                <div className="flex-1 min-w-0">
                  <p className={clsx('font-medium truncate', task.completed && 'line-through text-navy-400 dark:text-ink-500')}>
                    {task.title}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 mt-1.5">
                    <span className={clsx('text-[11px] font-semibold uppercase tracking-wide rounded-full px-2 py-0.5', PRIORITY_STYLES[task.priority])}>
                      {task.priority}
                    </span>
                    <span className="text-[11px] text-navy-500 dark:text-ink-500 rounded-full bg-navy-50 dark:bg-white/5 px-2 py-0.5">
                      {task.category}
                    </span>
                    {task.dueDate && (
                      <span className="text-[11px] text-navy-500 dark:text-ink-500">Due {new Date(task.dueDate).toLocaleDateString()}</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => openEditForm(task)} aria-label="Edit task" className="p-1.5 rounded-lg text-navy-400 hover:text-electric-500 hover:bg-electric-500/10">
                    <Pencil size={14} />
                  </button>
                  <button onClick={() => deleteTask(task.id)} aria-label="Delete task" className="p-1.5 rounded-lg text-navy-400 hover:text-red-500 hover:bg-red-500/10">
                    <Trash2 size={14} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}

        {tasks.length > 0 && (
          <p className="text-xs text-navy-400 dark:text-ink-500 mt-5 flex items-center gap-1">
            <X size={12} className="opacity-0" />{activeCount} active task{activeCount !== 1 ? 's' : ''} remaining
          </p>
        )}
      </Card>
    </ProductivityToolLayout>
  );
}
