import { useEffect, useMemo, useState } from 'react';
import { Hourglass, Plus, Trash2, Bell, BellOff } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { clsx } from '@/lib/utils/clsx';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import { daysRemaining, type CountdownExam, type ExamPriority } from '../logic/examCountdownTypes';

const tool = getProductivityToolBySlug('exam-countdown')!;

const PRIORITY_STYLES: Record<ExamPriority, string> = {
  low: 'bg-emerald-500/10 text-emerald-500',
  medium: 'bg-violet-500/10 text-violet-500',
  high: 'bg-red-500/10 text-red-500',
};

function emptyDraft() {
  return { name: '', subject: '', date: '', priority: 'medium' as ExamPriority };
}

export default function ExamCountdownPage() {
  const [exams, setExams] = useLocalStorage<CountdownExam[]>('ar-exam-countdowns', []);
  const [draft, setDraft] = useState(emptyDraft());
  const [formOpen, setFormOpen] = useState(false);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission | 'unsupported'>('unsupported');

  useEffect(() => {
    if (typeof Notification !== 'undefined') setNotifPermission(Notification.permission);
  }, []);

  const sorted = useMemo(() => [...exams].sort((a, b) => a.date.localeCompare(b.date)), [exams]);

  function addExam() {
    if (!draft.name.trim() || !draft.date) return;
    const exam: CountdownExam = { id: crypto.randomUUID(), ...draft, name: draft.name.trim() };
    setExams((prev) => [...prev, exam]);

    // Notification architecture: schedule a browser notification if permission is already granted
    // and the exam is within the next 30 days. This runs entirely client-side.
    if (notifPermission === 'granted') {
      const msUntil = new Date(exam.date).getTime() - Date.now() - 24 * 60 * 60 * 1000; // 1 day before
      if (msUntil > 0 && msUntil < 30 * 24 * 60 * 60 * 1000) {
        window.setTimeout(() => {
          new Notification(`Exam tomorrow: ${exam.name}`, { body: exam.subject || 'Good luck!' });
        }, msUntil);
      }
    }

    setDraft(emptyDraft());
    setFormOpen(false);
  }

  async function requestNotifications() {
    if (typeof Notification === 'undefined') return;
    const result = await Notification.requestPermission();
    setNotifPermission(result);
  }

  function removeExam(id: string) {
    setExams((prev) => prev.filter((e) => e.id !== id));
  }

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/exam-countdown"
      icon={Hourglass}
      breadcrumb={{ label: 'Exam Countdown' }}
      headerActions={<Button icon={<Plus size={16} />} onClick={() => setFormOpen((v) => !v)}>Add exam</Button>}
    >
      <Card>
        {notifPermission !== 'unsupported' && (
          <SoftCard className="mb-5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm text-navy-600 dark:text-ink-300">
              {notifPermission === 'granted' ? <Bell size={16} className="text-emerald-500" /> : <BellOff size={16} className="text-navy-400" />}
              {notifPermission === 'granted'
                ? 'Browser notifications are enabled — you\'ll get a reminder the day before each exam.'
                : 'Enable browser notifications to get reminders the day before an exam.'}
            </div>
            {notifPermission !== 'granted' && (
              <Button size="sm" variant="outline" onClick={requestNotifications}>Enable</Button>
            )}
          </SoftCard>
        )}

        {formOpen && (
          <SoftCard className="mb-5">
            <div className="grid sm:grid-cols-2 gap-3">
              <input autoFocus type="text" placeholder="Exam name" value={draft.name} onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20" />
              <input type="text" placeholder="Subject" value={draft.subject} onChange={(e) => setDraft((d) => ({ ...d, subject: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500" />
              <input type="datetime-local" value={draft.date} onChange={(e) => setDraft((d) => ({ ...d, date: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500" />
              <select value={draft.priority} onChange={(e) => setDraft((d) => ({ ...d, priority: e.target.value as ExamPriority }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500">
                <option value="low">Low priority</option>
                <option value="medium">Medium priority</option>
                <option value="high">High priority</option>
              </select>
            </div>
            <div className="flex gap-2 mt-4">
              <Button size="sm" onClick={addExam}>Add exam</Button>
              <Button size="sm" variant="ghost" onClick={() => setFormOpen(false)}>Cancel</Button>
            </div>
          </SoftCard>
        )}

        {sorted.length === 0 ? (
          <EmptyState icon={Hourglass} title="No exams tracked yet" description="Add an exam to see a live countdown here." />
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {sorted.map((exam) => {
              const days = daysRemaining(exam.date);
              return (
                <SoftCard key={exam.id} className="relative">
                  <button onClick={() => removeExam(exam.id)} aria-label="Remove exam" className="absolute top-3 right-3 text-navy-400 hover:text-red-500">
                    <Trash2 size={14} />
                  </button>
                  <span className={clsx('inline-block text-[11px] font-semibold uppercase tracking-wide rounded-full px-2 py-0.5 mb-3', PRIORITY_STYLES[exam.priority])}>
                    {exam.priority}
                  </span>
                  <p className="font-semibold">{exam.name}</p>
                  {exam.subject && <p className="text-sm text-navy-500 dark:text-ink-500">{exam.subject}</p>}
                  <p className="text-3xl font-display font-semibold text-gradient-brand mt-4">
                    {days > 0 ? `${days}d` : days === 0 ? 'Today' : 'Passed'}
                  </p>
                  <p className="text-xs text-navy-400 dark:text-ink-500 mt-1">{new Date(exam.date).toLocaleString()}</p>
                </SoftCard>
              );
            })}
          </div>
        )}
      </Card>
    </ProductivityToolLayout>
  );
}
