import { useEffect, useRef, useState } from 'react';
import { Timer as TimerIcon, Play, Pause, RotateCcw, Settings } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import { playBeep } from '../logic/pomodoroSound';

const tool = getProductivityToolBySlug('pomodoro-timer')!;

type Mode = 'work' | 'break';

interface PomodoroSettings {
  workMinutes: number;
  breakMinutes: number;
  soundEnabled: boolean;
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

export default function PomodoroTimerPage() {
  const [settings, setSettings] = useLocalStorage<PomodoroSettings>('ar-pomodoro-settings', {
    workMinutes: 25,
    breakMinutes: 5,
    soundEnabled: true,
  });
  const [dailyStats, setDailyStats] = useLocalStorage<Record<string, number>>('ar-pomodoro-stats', {});
  const [mode, setMode] = useState<Mode>('work');
  const [secondsLeft, setSecondsLeft] = useState(settings.workMinutes * 60);
  const [running, setRunning] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!running) return;
    intervalRef.current = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          handleSessionComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  function handleSessionComplete() {
    if (settings.soundEnabled) playBeep();
    if (mode === 'work') {
      setDailyStats((prev) => ({ ...prev, [todayKey()]: (prev[todayKey()] ?? 0) + 1 }));
      setMode('break');
      setSecondsLeft(settings.breakMinutes * 60);
    } else {
      setMode('work');
      setSecondsLeft(settings.workMinutes * 60);
    }
    setRunning(false);
  }

  function reset() {
    setRunning(false);
    setMode('work');
    setSecondsLeft(settings.workMinutes * 60);
  }

  function applySettings(next: PomodoroSettings) {
    setSettings(next);
    setRunning(false);
    setMode('work');
    setSecondsLeft(next.workMinutes * 60);
  }

  const minutes = String(Math.floor(secondsLeft / 60)).padStart(2, '0');
  const seconds = String(secondsLeft % 60).padStart(2, '0');
  const total = (mode === 'work' ? settings.workMinutes : settings.breakMinutes) * 60;
  const progress = total > 0 ? 1 - secondsLeft / total : 0;
  const todaySessions = dailyStats[todayKey()] ?? 0;

  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const key = d.toISOString().slice(0, 10);
    return { key, label: d.toLocaleDateString(undefined, { weekday: 'short' }), count: dailyStats[key] ?? 0 };
  });
  const maxCount = Math.max(1, ...last7Days.map((d) => d.count));

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/pomodoro-timer"
      icon={TimerIcon}
      breadcrumb={{ label: 'Pomodoro Timer' }}
      headerActions={
        <Button variant="outline" size="sm" icon={<Settings size={14} />} onClick={() => setShowSettings((v) => !v)}>
          Settings
        </Button>
      }
    >
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <Card className="flex flex-col items-center justify-center py-14">
          <span className="text-xs font-semibold uppercase tracking-wide text-navy-500 dark:text-ink-500 mb-4">
            {mode === 'work' ? 'Focus session' : 'Break time'}
          </span>

          <div className="relative flex items-center justify-center h-56 w-56 sm:h-64 sm:w-64">
            <svg className="absolute inset-0 -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="6" className="text-navy-100 dark:text-white/10" />
              <circle
                cx="50" cy="50" r="45" fill="none" stroke="url(#pomodoroGradient)" strokeWidth="6" strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 45}
                strokeDashoffset={2 * Math.PI * 45 * (1 - progress)}
                style={{ transition: 'stroke-dashoffset 1s linear' }}
              />
              <defs>
                <linearGradient id="pomodoroGradient" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#3b6dfb" />
                  <stop offset="100%" stopColor="#8b3ffb" />
                </linearGradient>
              </defs>
            </svg>
            <span className="text-5xl font-display font-semibold tabular-nums">{minutes}:{seconds}</span>
          </div>

          {showSettings ? (
            <SoftCard className="mt-8 w-full max-w-sm">
              <div className="grid grid-cols-2 gap-3 mb-3">
                <label className="text-sm">
                  Work (min)
                  <input type="number" min={1} value={settings.workMinutes} onChange={(e) => applySettings({ ...settings, workMinutes: Number(e.target.value) || 1 })} className="mt-1 w-full rounded-lg border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 outline-none focus:border-electric-500" />
                </label>
                <label className="text-sm">
                  Break (min)
                  <input type="number" min={1} value={settings.breakMinutes} onChange={(e) => applySettings({ ...settings, breakMinutes: Number(e.target.value) || 1 })} className="mt-1 w-full rounded-lg border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-2 outline-none focus:border-electric-500" />
                </label>
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={settings.soundEnabled} onChange={(e) => setSettings({ ...settings, soundEnabled: e.target.checked })} className="accent-electric-500" />
                Sound notifications
              </label>
            </SoftCard>
          ) : (
            <div className="flex items-center gap-3 mt-8">
              <Button size="lg" icon={running ? <Pause size={18} /> : <Play size={18} />} onClick={() => setRunning((v) => !v)}>
                {running ? 'Pause' : 'Start'}
              </Button>
              <Button size="lg" variant="outline" icon={<RotateCcw size={18} />} onClick={reset}>Reset</Button>
            </div>
          )}
        </Card>

        <Card>
          <h2 className="font-semibold mb-1">Today</h2>
          <p className="text-3xl font-display font-semibold text-gradient-brand mb-6">{todaySessions} session{todaySessions !== 1 ? 's' : ''}</p>

          <h3 className="text-sm font-semibold text-navy-500 dark:text-ink-400 mb-3">Last 7 days</h3>
          <div className="flex items-end gap-2 h-28">
            {last7Days.map((d) => (
              <div key={d.key} className="flex-1 flex flex-col items-center gap-1.5">
                <div className="w-full rounded-t-md gradient-brand" style={{ height: `${Math.max(4, (d.count / maxCount) * 100)}%` }} />
                <span className="text-[10px] text-navy-400 dark:text-ink-500">{d.label}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </ProductivityToolLayout>
  );
}
