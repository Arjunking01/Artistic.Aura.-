import { useState } from 'react';
import { CalendarDays, Plus, Trash2 } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card } from '@/components/ui/Card';
import { EmptyState } from '@/components/ui/EmptyState';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import { WEEK_DAYS, LABEL_COLORS, type WeeklyItem } from '../logic/weeklyPlannerTypes';

const tool = getProductivityToolBySlug('weekly-planner')!;

export default function WeeklyPlannerPage() {
  const [items, setItems] = useLocalStorage<WeeklyItem[]>('ar-weekly-planner', []);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [labelType, setLabelType] = useState<Record<string, 'subject' | 'task'>>({});

  function addItem(day: string) {
    const title = (drafts[day] ?? '').trim();
    if (!title) return;
    const item: WeeklyItem = {
      id: crypto.randomUUID(),
      day,
      title,
      label: labelType[day] ?? 'task',
      color: LABEL_COLORS[items.filter((i) => i.day === day).length % LABEL_COLORS.length],
    };
    setItems((prev) => [...prev, item]);
    setDrafts((prev) => ({ ...prev, [day]: '' }));
  }

  function removeItem(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/weekly-planner"
      icon={CalendarDays}
      breadcrumb={{ label: 'Weekly Planner' }}
    >
      <Card>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-3">
          {WEEK_DAYS.map((day) => {
            const dayItems = items.filter((i) => i.day === day);
            return (
              <div key={day} className="rounded-2xl border border-navy-100 dark:border-white/10 p-3 flex flex-col gap-2 min-h-[220px]">
                <p className="font-semibold text-sm text-center pb-2 border-b border-navy-100 dark:border-white/10">{day}</p>

                {dayItems.length === 0 ? (
                  <div className="flex-1 flex items-center justify-center">
                    <EmptyState icon={CalendarDays} title="Nothing planned" description="Add a task or subject below." />
                  </div>
                ) : (
                  <ul className="flex-1 space-y-1.5">
                    {dayItems.map((item) => (
                      <li key={item.id} className="group flex items-center justify-between gap-1.5 rounded-lg px-2.5 py-1.5 text-white text-xs" style={{ background: item.color }}>
                        <span className="truncate">{item.title}</span>
                        <button onClick={() => removeItem(item.id)} aria-label="Remove item" className="opacity-0 group-hover:opacity-100 shrink-0">
                          <Trash2 size={12} />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}

                <div className="space-y-1.5 pt-1">
                  <input
                    type="text"
                    placeholder="Add item..."
                    value={drafts[day] ?? ''}
                    onChange={(e) => setDrafts((prev) => ({ ...prev, [day]: e.target.value }))}
                    onKeyDown={(e) => e.key === 'Enter' && addItem(day)}
                    className="w-full rounded-lg border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-2.5 py-1.5 text-xs outline-none focus:border-electric-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <select
                      value={labelType[day] ?? 'task'}
                      onChange={(e) => setLabelType((prev) => ({ ...prev, [day]: e.target.value as 'subject' | 'task' }))}
                      className="flex-1 rounded-lg border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-2 py-1.5 text-xs outline-none focus:border-electric-500"
                    >
                      <option value="task">Task</option>
                      <option value="subject">Subject</option>
                    </select>
                    <button onClick={() => addItem(day)} aria-label={`Add to ${day}`} className="flex h-7 w-7 items-center justify-center rounded-lg gradient-brand text-white shrink-0">
                      <Plus size={13} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </ProductivityToolLayout>
  );
}
