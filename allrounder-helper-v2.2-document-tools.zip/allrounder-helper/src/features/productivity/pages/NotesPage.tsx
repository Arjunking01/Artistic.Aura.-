import { useEffect, useMemo, useState } from 'react';
import { StickyNote, Plus, Trash2, Pin, Search } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { clsx } from '@/lib/utils/clsx';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import { NOTE_CATEGORIES, type Note } from '../logic/notesTypes';

const tool = getProductivityToolBySlug('notes')!;

function newNote(): Note {
  return { id: crypto.randomUUID(), title: '', content: '', category: NOTE_CATEGORIES[0], pinned: false, updatedAt: new Date().toISOString() };
}

export default function NotesPage() {
  const [notes, setNotes] = useLocalStorage<Note[]>('ar-notes', []);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [draft, setDraft] = useState<Note | null>(null);

  const filtered = useMemo(() => {
    return notes
      .filter((n) => n.title.toLowerCase().includes(search.toLowerCase()) || n.content.toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt));
  }, [notes, search]);

  useEffect(() => {
    if (activeId) setDraft(notes.find((n) => n.id === activeId) ?? null);
    else setDraft(null);
  }, [activeId, notes]);

  // Auto-save with a short debounce whenever the draft changes.
  useEffect(() => {
    if (!draft) return;
    const timeout = setTimeout(() => {
      setNotes((prev) => prev.map((n) => (n.id === draft.id ? { ...draft, updatedAt: new Date().toISOString() } : n)));
    }, 400);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draft]);

  function createNote() {
    const note = newNote();
    setNotes((prev) => [note, ...prev]);
    setActiveId(note.id);
  }

  function deleteNote(id: string) {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    if (activeId === id) setActiveId(null);
  }

  function togglePin(id: string) {
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)));
  }

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/notes"
      icon={StickyNote}
      breadcrumb={{ label: 'Notes' }}
      headerActions={<Button icon={<Plus size={16} />} onClick={createNote}>New note</Button>}
    >
      <div className="grid lg:grid-cols-[320px_1fr] gap-5">
        <Card className="p-4 sm:p-4">
          <div className="relative mb-3">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              type="text"
              placeholder="Search notes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 pl-9 pr-4 py-2 text-sm outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20"
            />
          </div>

          {filtered.length === 0 ? (
            <EmptyState icon={StickyNote} title="No notes yet" description="Create your first note to see it here." />
          ) : (
            <ul className="space-y-1.5 max-h-[60vh] overflow-y-auto">
              {filtered.map((note) => (
                <li key={note.id}>
                  <button
                    onClick={() => setActiveId(note.id)}
                    className={clsx(
                      'w-full text-left rounded-xl px-3.5 py-2.5 transition-colors',
                      activeId === note.id ? 'bg-electric-500/10 text-electric-600 dark:text-electric-400' : 'hover:bg-navy-50 dark:hover:bg-white/5'
                    )}
                  >
                    <div className="flex items-center gap-1.5">
                      {note.pinned && <Pin size={11} className="text-violet-500 shrink-0" />}
                      <span className="font-medium text-sm truncate">{note.title || 'Untitled note'}</span>
                    </div>
                    <p className="text-xs text-navy-500 dark:text-ink-500 truncate mt-0.5">{note.content || 'No content yet'}</p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          {draft ? (
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between gap-3 mb-4">
                <input
                  type="text"
                  placeholder="Note title"
                  value={draft.title}
                  onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                  className="flex-1 text-xl font-semibold bg-transparent outline-none placeholder:text-navy-300 dark:placeholder:text-ink-600"
                />
                <div className="flex items-center gap-1">
                  <button onClick={() => togglePin(draft.id)} aria-label="Pin note" className={clsx('p-2 rounded-lg', draft.pinned ? 'text-violet-500 bg-violet-500/10' : 'text-navy-400 hover:bg-navy-50 dark:hover:bg-white/5')}>
                    <Pin size={16} />
                  </button>
                  <button onClick={() => deleteNote(draft.id)} aria-label="Delete note" className="p-2 rounded-lg text-navy-400 hover:text-red-500 hover:bg-red-500/10">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <select
                value={draft.category}
                onChange={(e) => setDraft({ ...draft, category: e.target.value })}
                className="w-fit mb-4 rounded-lg border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-3 py-1.5 text-xs outline-none focus:border-electric-500"
              >
                {NOTE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <textarea
                placeholder="Write in markdown — **bold**, _italic_, - lists..."
                value={draft.content}
                onChange={(e) => setDraft({ ...draft, content: e.target.value })}
                className="flex-1 min-h-[320px] w-full resize-none bg-transparent outline-none text-sm leading-relaxed text-navy-700 dark:text-ink-300 placeholder:text-navy-300 dark:placeholder:text-ink-600"
              />
              <p className="text-xs text-navy-400 dark:text-ink-500 mt-3">Saved automatically</p>
            </div>
          ) : (
            <SoftCard className="border-dashed">
              <EmptyState icon={StickyNote} title="Select or create a note" description="Choose a note from the list, or start a new one to begin writing." />
            </SoftCard>
          )}
        </Card>
      </div>
    </ProductivityToolLayout>
  );
}
