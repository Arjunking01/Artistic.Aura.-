import { useMemo, useState } from 'react';
import { Flame, Plus, Trash2 } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { clsx } from '@/lib/utils/clsx';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import { HABIT_COLORS, currentStreak, dateKey, type Habit } from '../logic/habitTypes';

const tool = getProductivityToolBySlug('habit-tracker')!;

function last35Days(): Date[] {
  return Array.from({ length: 35 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (34 - i));
    return d;
  });
}

function lastNDays(n: number): Date[] {
  return Array.from({ length: n }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (n - 1 - i));
    return d;
  });
}

export default function HabitTrackerPage() {
  const [habits, setHabits] = useLocalStorage<Habit[]>('ar-habits', []);
  const [name, setName] = useState('');
  const week = useMemo(() => lastNDays(7), []);
  const month = useMemo(() => last35Days(), []);

  function addHabit() {
    if (!name.trim()) return;
    const habit: Habit = { id: crypto.randomUUID(), name: name.trim(), color: HABIT_COLORS[habits.length % HABIT_COLORS.length], createdAt: new Date().toISOString(), completions: {} };
    setHabits((prev) => [...prev, habit]);
    setName('');
  }

  function toggleDay(habitId: string, key: string) {
    setHabits((prev) =>
      prev.map((h) => (h.id === habitId ? { ...h, completions: { ...h.completions, [key]: !h.completions[key] } } : h))
    );
  }

  function removeHabit(id: string) {
    setHabits((prev) => prev.filter((h) => h.id !== id));
  }

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/habit-tracker"
      icon={Flame}
      breadcrumb={{ label: 'Habit Tracker' }}
    >
      <Card>
        <div className="flex gap-2 mb-6">
          <input
            type="text"
            placeholder="Add a habit, e.g. Read for 20 minutes"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addHabit()}
            className="flex-1 rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20"
          />
          <Button icon={<Plus size={16} />} onClick={addHabit}>Add</Button>
        </div>

        {habits.length === 0 ? (
          <EmptyState icon={Flame} title="No habits yet" description="Add a daily habit to start building a streak." />
        ) : (
          <div className="space-y-8">
            {habits.map((habit) => (
              <div key={habit.id}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: habit.color }} />
                    <span className="font-medium">{habit.name}</span>
                    <span className="text-xs text-navy-500 dark:text-ink-500 rounded-full bg-navy-50 dark:bg-white/5 px-2 py-0.5">
                      🔥 {currentStreak(habit)} day streak
                    </span>
                  </div>
                  <button onClick={() => removeHabit(habit.id)} aria-label="Remove habit" className="text-navy-400 hover:text-red-500">
                    <Trash2 size={14} />
                  </button>
                </div>

                {/* Weekly view */}
                <div className="flex gap-1.5 mb-3">
                  {week.map((d) => {
                    const key = dateKey(d);
                    const done = habit.completions[key];
                    return (
                      <button
                        key={key}
                        onClick={() => toggleDay(habit.id, key)}
                        className={clsx(
                          'flex-1 flex flex-col items-center gap-1 rounded-xl border py-2 text-xs transition-colors',
                          done ? 'text-white border-transparent' : 'border-navy-100 dark:border-white/10 text-navy-400 hover:border-electric-500'
                        )}
                        style={done ? { background: habit.color } : undefined}
                      >
                        {d.toLocaleDateString(undefined, { weekday: 'narrow' })}
                        <span>{d.getDate()}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Monthly streak heatmap */}
                <div className="grid grid-cols-[repeat(35,minmax(0,1fr))] gap-1">
                  {month.map((d) => {
                    const key = dateKey(d);
                    const done = habit.completions[key];
                    return (
                      <div
                        key={key}
                        title={key}
                        className={clsx('aspect-square rounded-sm', !done && 'bg-navy-100 dark:bg-white/10')}
                        style={done ? { background: habit.color } : undefined}
                      />
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </ProductivityToolLayout>
  );
}
