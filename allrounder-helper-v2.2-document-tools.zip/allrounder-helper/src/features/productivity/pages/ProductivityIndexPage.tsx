import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Seo, SITE_URL } from '@/components/Seo';
import { Breadcrumbs, breadcrumbJsonLd } from '@/components/ui/Breadcrumbs';
import { productivityTools } from '@/data/productivityRegistry';

export default function ProductivityIndexPage() {
  return (
    <div className="noise-bg">
      <Seo
        title="Productivity Tools"
        description="Free productivity tools for students — to-do lists, notes, study planner, Pomodoro timer, goal and habit tracking, exam countdowns, and a weekly planner. All saved locally on your device."
        path="/productivity"
        jsonLd={breadcrumbJsonLd([{ label: 'Productivity' }], SITE_URL)}
      />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 pt-8">
        <Breadcrumbs items={[{ label: 'Productivity' }]} />
      </div>
      <header className="mx-auto max-w-6xl px-4 sm:px-6 pt-8 pb-10">
        <h1 className="text-3xl sm:text-4xl font-semibold">Productivity</h1>
        <p className="mt-3 text-navy-500 dark:text-ink-400 max-w-2xl">
          Eight tools to plan, focus, and build momentum — every one of them saves automatically to your device, no account required.
        </p>
      </header>

      <div className="mx-auto max-w-6xl px-4 sm:px-6 pb-24 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {productivityTools.map((tool, i) => (
          <motion.div
            key={tool.slug}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: i * 0.03 }}
          >
            <Link
              to={`/productivity/${tool.slug}`}
              className="group flex flex-col gap-3 rounded-2xl border border-navy-100 dark:border-white/10 p-5 hover:border-electric-500 hover:shadow-lg hover:shadow-electric-500/5 transition-all h-full"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-brand text-white">
                <tool.icon size={18} />
              </div>
              <div>
                <h2 className="font-semibold group-hover:text-electric-500 transition-colors">{tool.name}</h2>
                <p className="text-sm text-navy-500 dark:text-ink-500 mt-1">{tool.tagline}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
