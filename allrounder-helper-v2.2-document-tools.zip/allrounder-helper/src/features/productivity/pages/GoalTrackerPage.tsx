import { useMemo, useState } from 'react';
import { Target, Plus, Trash2 } from 'lucide-react';
import { ProductivityToolLayout } from '@/components/ProductivityToolLayout';
import { Card, SoftCard } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { clsx } from '@/lib/utils/clsx';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getProductivityToolBySlug } from '@/data/productivityRegistry';
import { GOAL_CATEGORIES, type Goal, type GoalType } from '../logic/goalTypes';

const tool = getProductivityToolBySlug('goal-tracker')!;

function emptyDraft() {
  return { title: '', category: GOAL_CATEGORIES[0], type: 'short-term' as GoalType, deadline: '' };
}

export default function GoalTrackerPage() {
  const [goals, setGoals] = useLocalStorage<Goal[]>('ar-goals', []);
  const [tab, setTab] = useState<GoalType | 'all'>('all');
  const [draft, setDraft] = useState(emptyDraft());
  const [formOpen, setFormOpen] = useState(false);

  const filtered = useMemo(() => (tab === 'all' ? goals : goals.filter((g) => g.type === tab)), [goals, tab]);

  function addGoal() {
    if (!draft.title.trim()) return;
    const goal: Goal = { id: crypto.randomUUID(), ...draft, title: draft.title.trim(), progress: 0, completed: false, createdAt: new Date().toISOString() };
    setGoals((prev) => [goal, ...prev]);
    setDraft(emptyDraft());
    setFormOpen(false);
  }

  function updateProgress(id: string, progress: number) {
    setGoals((prev) => prev.map((g) => (g.id === id ? { ...g, progress, completed: progress >= 100 } : g)));
  }

  function removeGoal(id: string) {
    setGoals((prev) => prev.filter((g) => g.id !== id));
  }

  return (
    <ProductivityToolLayout
      toolName={tool.name}
      tagline={tool.tagline}
      description={tool.description}
      path="/productivity/goal-tracker"
      icon={Target}
      breadcrumb={{ label: 'Goal Tracker' }}
      headerActions={<Button icon={<Plus size={16} />} onClick={() => setFormOpen((v) => !v)}>New goal</Button>}
    >
      <Card>
        <div className="flex gap-1 rounded-xl bg-navy-50 dark:bg-white/5 p-1 w-fit mb-5">
          {(['all', 'short-term', 'long-term'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={clsx(
                'px-3.5 py-1.5 rounded-lg text-sm font-medium capitalize transition-colors',
                tab === t ? 'bg-white dark:bg-navy-800 text-electric-500 shadow-sm' : 'text-navy-500 dark:text-ink-400'
              )}
            >
              {t.replace('-', ' ')}
            </button>
          ))}
        </div>

        {formOpen && (
          <SoftCard className="mb-5">
            <div className="grid sm:grid-cols-2 gap-3">
              <input
                autoFocus type="text" placeholder="Goal title" value={draft.title}
                onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
                className="sm:col-span-2 rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500 focus:ring-2 focus:ring-electric-500/20"
              />
              <select value={draft.category} onChange={(e) => setDraft((d) => ({ ...d, category: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500">
                {GOAL_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={draft.type} onChange={(e) => setDraft((d) => ({ ...d, type: e.target.value as GoalType }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500">
                <option value="short-term">Short-term</option>
                <option value="long-term">Long-term</option>
              </select>
              <input type="date" value={draft.deadline} onChange={(e) => setDraft((d) => ({ ...d, deadline: e.target.value }))} className="rounded-xl border border-navy-200 dark:border-white/10 bg-white dark:bg-navy-900/60 px-4 py-2.5 outline-none focus:border-electric-500" />
            </div>
            <div className="flex gap-2 mt-4">
              <Button size="sm" onClick={addGoal}>Add goal</Button>
              <Button size="sm" variant="ghost" onClick={() => setFormOpen(false)}>Cancel</Button>
            </div>
          </SoftCard>
        )}

        {filtered.length === 0 ? (
          <EmptyState icon={Target} title="No goals here yet" description="Set a short or long-term goal to start tracking progress." />
        ) : (
          <div className="grid sm:grid-cols-2 gap-3">
            {filtered.map((goal) => (
              <SoftCard key={goal.id}>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <p className={clsx('font-medium', goal.completed && 'text-emerald-500')}>{goal.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[11px] text-navy-500 dark:text-ink-500 rounded-full bg-navy-100 dark:bg-white/5 px-2 py-0.5">{goal.category}</span>
                      <span className="text-[11px] text-navy-500 dark:text-ink-500 capitalize">{goal.type.replace('-', ' ')}</span>
                      {goal.deadline && <span className="text-[11px] text-navy-500 dark:text-ink-500">Due {new Date(goal.deadline).toLocaleDateString()}</span>}
                    </div>
                  </div>
                  <button onClick={() => removeGoal(goal.id)} aria-label="Remove goal" className="text-navy-400 hover:text-red-500 shrink-0">
                    <Trash2 size={14} />
                  </button>
                </div>
                <input type="range" min={0} max={100} value={goal.progress} onChange={(e) => updateProgress(goal.id, Number(e.target.value))} className="w-full accent-electric-500" />
                <span className="text-xs text-navy-500 dark:text-ink-500">{goal.progress}% complete{goal.completed && ' · 🎉 Done'}</span>
              </SoftCard>
            ))}
          </div>
        )}
      </Card>
    </ProductivityToolLayout>
  );
}
