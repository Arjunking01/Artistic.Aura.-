export interface Note {
  id: string;
  title: string;
  content: string;
  category: string;
  pinned: boolean;
  updatedAt: string;
}

export const NOTE_CATEGORIES = ['General', 'Lecture Notes', 'Ideas', 'To Review'];
