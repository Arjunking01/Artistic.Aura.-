export interface Habit {
  id: string;
  name: string;
  color: string;
  createdAt: string;
  /** Map of 'YYYY-MM-DD' -> completed */
  completions: Record<string, boolean>;
}

export const HABIT_COLORS = ['#3b6dfb', '#8b3ffb', '#17cf8f', '#fb923c', '#f43f5e'];

export function dateKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

export function currentStreak(habit: Habit): number {
  let streak = 0;
  const cursor = new Date();
  while (habit.completions[dateKey(cursor)]) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}
