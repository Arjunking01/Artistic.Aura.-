export interface Subject {
  id: string;
  name: string;
  color: string;
  progress: number; // 0-100, manually tracked
}

export interface StudySession {
  id: string;
  subjectId: string;
  day: string; // 'Mon'..'Sun'
  startTime: string;
  endTime: string;
}

export interface ExamPlan {
  id: string;
  subjectId: string;
  date: string;
  notes?: string;
}

export interface StudyGoal {
  id: string;
  text: string;
  done: boolean;
}

export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const SUBJECT_COLORS = ['#3b6dfb', '#8b3ffb', '#17cf8f', '#fb923c', '#f43f5e', '#06b6d4'];
