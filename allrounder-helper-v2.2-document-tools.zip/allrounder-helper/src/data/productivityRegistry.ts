import {
  CheckSquare, StickyNote, CalendarRange, Timer as TimerIcon,
  Target, Flame, Hourglass, CalendarDays,
  type LucideIcon,
} from 'lucide-react';

export interface ProductivityToolMeta {
  slug: string;
  name: string;
  shortName: string;
  tagline: string;
  description: string;
  icon: LucideIcon;
  /** Reserved for the future educational guide (blog integration). Left undefined until content ships. */
  guideSlug?: string;
}

export const productivityTools: ProductivityToolMeta[] = [
  {
    slug: 'todo-list',
    name: 'To-Do List',
    shortName: 'To-Do List',
    tagline: 'Track tasks with due dates, priorities, and categories.',
    description: 'A fast to-do list with due dates, priority levels, categories, search, and filters — saved automatically to your device.',
    icon: CheckSquare,
  },
  {
    slug: 'notes',
    name: 'Notes',
    shortName: 'Notes',
    tagline: 'Quick markdown notes that save as you type.',
    description: 'Create, search, and pin markdown notes with categories. Auto-saves locally so nothing is ever lost.',
    icon: StickyNote,
  },
  {
    slug: 'study-planner',
    name: 'Study Planner',
    shortName: 'Study Planner',
    tagline: 'Plan subjects, weekly sessions, and exam prep.',
    description: 'Organize subjects, build a weekly study schedule, plan for exams, and track progress toward study goals.',
    icon: CalendarRange,
  },
  {
    slug: 'pomodoro-timer',
    name: 'Pomodoro Timer',
    shortName: 'Pomodoro Timer',
    tagline: 'Focused work sessions with a 25/5 rhythm.',
    description: 'A customizable Pomodoro timer with session tracking, daily statistics, and sound notifications.',
    icon: TimerIcon,
  },
  {
    slug: 'goal-tracker',
    name: 'Goal Tracker',
    shortName: 'Goal Tracker',
    tagline: 'Track short and long-term goals to completion.',
    description: 'Set short-term and long-term goals with deadlines, categories, and progress tracking.',
    icon: Target,
  },
  {
    slug: 'habit-tracker',
    name: 'Habit Tracker',
    shortName: 'Habit Tracker',
    tagline: 'Build streaks with a daily and monthly view.',
    description: 'Track daily habits with a weekly checklist, monthly streak view, and completion history.',
    icon: Flame,
  },
  {
    slug: 'exam-countdown',
    name: 'Exam Countdown',
    shortName: 'Exam Countdown',
    tagline: 'Live countdowns for every upcoming exam.',
    description: 'Track multiple exams with live countdowns, priority levels, and optional browser notifications.',
    icon: Hourglass,
  },
  {
    slug: 'weekly-planner',
    name: 'Weekly Planner',
    shortName: 'Weekly Planner',
    tagline: 'Plan your Monday-to-Sunday week at a glance.',
    description: 'A Monday-to-Sunday planner for tasks and subjects with color labels, auto-saved locally.',
    icon: CalendarDays,
  },
];

export function getProductivityToolBySlug(slug: string): ProductivityToolMeta | undefined {
  return productivityTools.find((t) => t.slug === slug);
}
