import { Loader2, CheckCircle2, XCircle } from 'lucide-react';

interface ProcessingIndicatorProps {
  status: 'idle' | 'processing' | 'success' | 'error';
  progress?: number; // 0-100
  message?: string;
}

export function ProcessingIndicator({ status, progress, message }: ProcessingIndicatorProps) {
  if (status === 'idle') return null;

  return (
    <div className="flex items-center gap-3 rounded-xl border border-navy-100 dark:border-white/10 px-4 py-3" role="status" aria-live="polite">
      {status === 'processing' && <Loader2 size={18} className="animate-spin text-electric-500 shrink-0" />}
      {status === 'success' && <CheckCircle2 size={18} className="text-emerald-500 shrink-0" />}
      {status === 'error' && <XCircle size={18} className="text-red-500 shrink-0" />}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-navy-800 dark:text-ink-100 truncate">
          {message ?? (status === 'processing' ? 'Processing...' : status === 'success' ? 'Done' : 'Something went wrong')}
        </p>
        {status === 'processing' && typeof progress === 'number' && (
          <div className="mt-1.5 h-1.5 w-full rounded-full bg-navy-100 dark:bg-white/10 overflow-hidden">
            <div className="h-full gradient-brand transition-all duration-200" style={{ width: `${Math.min(100, Math.max(0, progress))}%` }} />
          </div>
        )}
      </div>
    </div>
  );
}
