import type { ReactNode } from 'react';

interface ToolToolbarProps {
  children: ReactNode;
}

/** A horizontal row of action buttons/controls shared across document & image tools. */
export function ToolToolbar({ children }: ToolToolbarProps) {
  return <div className="flex flex-wrap items-center gap-2 mb-5">{children}</div>;
}
