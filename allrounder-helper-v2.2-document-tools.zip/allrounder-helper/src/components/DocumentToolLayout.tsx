import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { Breadcrumbs, breadcrumbJsonLd, type Crumb } from '@/components/ui/Breadcrumbs';
import { Seo, SITE_URL } from '@/components/Seo';
import { Card } from '@/components/ui/Card';
import { HistoryPanel } from '@/components/document/HistoryPanel';
import { useToolHistory } from '@/hooks/useToolHistory';

interface DocumentToolLayoutProps {
  toolName: string;
  tagline: string;
  description: string;
  path: string;
  icon: LucideIcon;
  breadcrumb: Crumb;
  toolSlug: string;
  showHistory?: boolean;
  children: ReactNode;
}

export function DocumentToolLayout({
  toolName,
  tagline,
  description,
  path,
  icon: Icon,
  breadcrumb,
  toolSlug,
  showHistory = true,
  children,
}: DocumentToolLayoutProps) {
  const crumbs: Crumb[] = [{ label: 'Document Tools', href: '/document-tools' }, breadcrumb];
  const { historyForTool, clearHistory } = useToolHistory();

  return (
    <div className="noise-bg min-h-[70vh]">
      <Seo title={toolName} description={description} path={path} jsonLd={breadcrumbJsonLd(crumbs, SITE_URL)} />
      <div className="mx-auto max-w-5xl px-4 sm:px-6 pt-8">
        <Breadcrumbs items={crumbs} />
      </div>

      <header className="mx-auto max-w-5xl px-4 sm:px-6 pt-8 pb-6">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }} className="flex items-center gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl gradient-brand text-white shadow-lg shadow-electric-500/20">
            <Icon size={22} />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-semibold">{toolName}</h1>
            <p className="text-navy-500 dark:text-ink-400 text-sm sm:text-base">{tagline}</p>
          </div>
        </motion.div>
      </header>

      <main className="mx-auto max-w-5xl px-4 sm:px-6 pb-20">
        <div className={showHistory ? 'grid lg:grid-cols-[1fr_260px] gap-6 items-start' : ''}>
          <div>{children}</div>
          {showHistory && (
            <Card className="p-4 sm:p-4">
              <HistoryPanel entries={historyForTool(toolSlug)} onClear={clearHistory} />
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
