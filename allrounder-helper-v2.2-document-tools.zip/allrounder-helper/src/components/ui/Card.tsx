import type { HTMLAttributes } from 'react';
import { clsx } from '@/lib/utils/clsx';

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={clsx(
        'glass-panel p-6 sm:p-8',
        className
      )}
      {...props}
    />
  );
}

export function SoftCard({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={clsx(
        'rounded-2xl border border-navy-100 dark:border-white/10 bg-navy-50/60 dark:bg-white/[0.03] p-5',
        className
      )}
      {...props}
    />
  );
}
