import { Link } from 'react-router-dom';
import { Sparkles } from 'lucide-react';

const COLUMNS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: 'Tools',
    links: [
      { label: 'Academic Tools', href: '/academic-tools' },
      { label: 'Productivity', href: '/productivity' },
      { label: 'Document Tools', href: '/document-tools' },
      { label: 'Creator Tools', href: '/creator-tools' },
      { label: 'Finance Tools', href: '/finance-tools' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About', href: '/about' },
      { label: 'Blog', href: '/blog' },
      { label: 'Contact', href: '/contact' },
    ],
  },
  {
    title: 'Legal',
    links: [
      { label: 'Privacy Policy', href: '/privacy-policy' },
      { label: 'Terms of Service', href: '/terms' },
      { label: 'Disclaimer', href: '/disclaimer' },
      { label: 'Cookie Policy', href: '/cookie-policy' },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-navy-100 dark:border-white/10 mt-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 grid grid-cols-2 sm:grid-cols-4 gap-10">
        <div className="col-span-2 sm:col-span-1">
          <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl gradient-brand text-white">
              <Sparkles size={16} />
            </span>
            ALLROUNDER
          </Link>
          <p className="mt-3 text-sm text-navy-500 dark:text-ink-500 max-w-xs">
            The everyday platform for students to calculate, plan, organize, and study smarter.
          </p>
        </div>
        {COLUMNS.map((col) => (
          <div key={col.title}>
            <h3 className="text-sm font-semibold text-navy-900 dark:text-ink-100 mb-3">{col.title}</h3>
            <ul className="space-y-2">
              {col.links.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-sm text-navy-500 dark:text-ink-500 hover:text-electric-500 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-navy-100 dark:border-white/10 py-6">
        <p className="text-center text-xs text-navy-400 dark:text-ink-500">
          © {new Date().getFullYear()} ALLROUNDER HELPER. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
