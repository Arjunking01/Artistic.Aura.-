import { Moon, Sun } from 'lucide-react';
import { useThemeStore } from '@/lib/store/theme';

export function ThemeToggle() {
  const { theme, toggle } = useThemeStore();
  return (
    <button
      onClick={toggle}
      aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      className="relative flex h-9 w-9 items-center justify-center rounded-full border border-navy-200 dark:border-white/10 text-navy-600 dark:text-ink-300 hover:border-electric-500 hover:text-electric-500 transition-colors"
    >
      {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  );
}
