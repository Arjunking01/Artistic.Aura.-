import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Menu, X, Sparkles } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { clsx } from '@/lib/utils/clsx';

const NAV_LINKS = [
  { label: 'Academic Tools', href: '/academic-tools' },
  { label: 'Productivity', href: '/productivity' },
  { label: 'Document Tools', href: '/document-tools' },
  { label: 'Creator Tools', href: '/creator-tools' },
  { label: 'Finance', href: '/finance-tools' },
  { label: 'Blog', href: '/blog' },
];

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-navy-100/80 dark:border-white/10 glass">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl gradient-brand text-white">
            <Sparkles size={16} />
          </span>
          <span>
            ALLROUNDER<span className="text-gradient-brand"> HELPER</span>
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.href}
              to={link.href}
              className={({ isActive }) =>
                clsx(
                  'rounded-full px-3.5 py-2 text-sm font-medium transition-colors',
                  isActive
                    ? 'text-electric-500 bg-electric-500/10'
                    : 'text-navy-600 dark:text-ink-300 hover:text-electric-500'
                )
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <button
            className="lg:hidden flex h-9 w-9 items-center justify-center rounded-full border border-navy-200 dark:border-white/10"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X size={16} /> : <Menu size={16} />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="lg:hidden border-t border-navy-100 dark:border-white/10 px-4 py-3 flex flex-col gap-1">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.href}
              to={link.href}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                clsx(
                  'rounded-xl px-3 py-2.5 text-sm font-medium',
                  isActive ? 'text-electric-500 bg-electric-500/10' : 'text-navy-600 dark:text-ink-300'
                )
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  );
}
