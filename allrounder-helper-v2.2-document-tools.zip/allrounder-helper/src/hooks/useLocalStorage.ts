import { useEffect, useRef, useState } from 'react';

function readValue<T>(key: string, initialValue: T): T {
  if (typeof window === 'undefined') return initialValue;
  try {
    const item = window.localStorage.getItem(key);
    return item ? (JSON.parse(item) as T) : initialValue;
  } catch {
    return initialValue;
  }
}

/**
 * Persists state to localStorage under `key`, keeping it in sync automatically.
 * Safe for SSR and gracefully falls back to in-memory state if storage is unavailable
 * (e.g. private browsing modes that throw on write).
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => readValue(key, initialValue));
  const isFirstRender = useRef(true);

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Storage unavailable (private mode, quota exceeded) — fail silently, keep in-memory state.
    }
  }, [key, value]);

  return [value, setValue] as const;
}
