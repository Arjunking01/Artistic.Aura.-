import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { RootLayout } from '@/components/layout/RootLayout';

const HomePage = lazy(() => import('@/pages/HomePage'));
const AcademicToolsPage = lazy(() => import('@/pages/AcademicToolsPage'));
const ProductivityIndexPage = lazy(() => import('@/features/productivity/pages/ProductivityIndexPage'));
const TodoListPage = lazy(() => import('@/features/productivity/pages/TodoListPage'));
const NotesPage = lazy(() => import('@/features/productivity/pages/NotesPage'));
const StudyPlannerPage = lazy(() => import('@/features/productivity/pages/StudyPlannerPage'));
const PomodoroTimerPage = lazy(() => import('@/features/productivity/pages/PomodoroTimerPage'));
const GoalTrackerPage = lazy(() => import('@/features/productivity/pages/GoalTrackerPage'));
const HabitTrackerPage = lazy(() => import('@/features/productivity/pages/HabitTrackerPage'));
const ExamCountdownPage = lazy(() => import('@/features/productivity/pages/ExamCountdownPage'));
const WeeklyPlannerPage = lazy(() => import('@/features/productivity/pages/WeeklyPlannerPage'));
const DocumentToolsIndexPage = lazy(() => import('@/features/document/pages/DocumentToolsIndexPage'));
const MergePdfPage = lazy(() => import('@/features/document/pages/MergePdfPage'));
const SplitPdfPage = lazy(() => import('@/features/document/pages/SplitPdfPage'));
const CompressPdfPage = lazy(() => import('@/features/document/pages/CompressPdfPage'));
const RotatePdfPage = lazy(() => import('@/features/document/pages/RotatePdfPage'));
const RearrangePdfPage = lazy(() => import('@/features/document/pages/RearrangePdfPage'));
const ExtractPdfPagesPage = lazy(() => import('@/features/document/pages/ExtractPdfPagesPage'));
const DeletePdfPagesPage = lazy(() => import('@/features/document/pages/DeletePdfPagesPage'));
const ImageToPdfPage = lazy(() => import('@/features/document/pages/ImageToPdfPage'));
const PdfToImagePage = lazy(() => import('@/features/document/pages/PdfToImagePage'));
const WordToPdfPage = lazy(() => import('@/features/document/pages/WordToPdfPage'));
const PdfTextExtractPage = lazy(() => import('@/features/document/pages/PdfTextExtractPage'));
const OcrArchitecturePage = lazy(() => import('@/features/document/pages/OcrArchitecturePage'));
const ImageCompressorPage = lazy(() => import('@/features/document/pages/ImageCompressorPage'));
const ImageResizerPage = lazy(() => import('@/features/document/pages/ImageResizerPage'));
const ImageCropperPage = lazy(() => import('@/features/document/pages/ImageCropperPage'));
const ImageFormatConverterPage = lazy(() => import('@/features/document/pages/ImageFormatConverterPage'));
const JpgPngConverterPage = lazy(() => import('@/features/document/pages/JpgPngConverterPage'));
const WebpConverterPage = lazy(() => import('@/features/document/pages/WebpConverterPage'));
const ImageMetadataViewerPage = lazy(() => import('@/features/document/pages/ImageMetadataViewerPage'));
const QrGeneratorPage = lazy(() => import('@/features/document/pages/QrGeneratorPage'));
const QrScannerPage = lazy(() => import('@/features/document/pages/QrScannerPage'));
const BarcodeGeneratorPage = lazy(() => import('@/features/document/pages/BarcodeGeneratorPage'));
const CreatorToolsPage = lazy(() => import('@/pages/CreatorToolsPage'));
const FinanceToolsPage = lazy(() => import('@/pages/FinanceToolsPage'));
const BlogPage = lazy(() => import('@/pages/BlogPage'));
const AboutPage = lazy(() => import('@/pages/AboutPage'));
const ContactPage = lazy(() => import('@/pages/ContactPage'));
const PrivacyPolicyPage = lazy(() => import('@/pages/legal/PrivacyPolicyPage'));
const TermsPage = lazy(() => import('@/pages/legal/TermsPage'));
const DisclaimerPage = lazy(() => import('@/pages/legal/DisclaimerPage'));
const CookiePolicyPage = lazy(() => import('@/pages/legal/CookiePolicyPage'));
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage'));

const CgpaCalculatorPage = lazy(() => import('@/features/academic/pages/CgpaCalculatorPage'));
const SgpaCalculatorPage = lazy(() => import('@/features/academic/pages/SgpaCalculatorPage'));
const AttendanceCalculatorPage = lazy(() => import('@/features/academic/pages/AttendanceCalculatorPage'));
const PercentageCalculatorPage = lazy(() => import('@/features/academic/pages/PercentageCalculatorPage'));
const GpaToPercentagePage = lazy(() => import('@/features/academic/pages/GpaToPercentagePage'));
const SemesterPercentagePage = lazy(() => import('@/features/academic/pages/SemesterPercentagePage'));
const MarksRequiredPage = lazy(() => import('@/features/academic/pages/MarksRequiredPage'));
const BudgetPlannerPage = lazy(() => import('@/features/academic/pages/BudgetPlannerPage'));
const ScientificCalculatorPage = lazy(() => import('@/features/academic/pages/ScientificCalculatorPage'));
const AssignmentScorePage = lazy(() => import('@/features/academic/pages/AssignmentScorePage'));
const ExamScorePage = lazy(() => import('@/features/academic/pages/ExamScorePage'));
const StudyHoursPage = lazy(() => import('@/features/academic/pages/StudyHoursPage'));
const DeadlineCalculatorPage = lazy(() => import('@/features/academic/pages/DeadlineCalculatorPage'));
const UnitConverterPage = lazy(() => import('@/features/academic/pages/UnitConverterPage'));

function PageFallback() {
  return (
    <div className="flex min-h-[50vh] items-center justify-center">
      <div className="h-8 w-8 rounded-full border-2 border-electric-500 border-t-transparent animate-spin" />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<PageFallback />}>
        <Routes>
          <Route element={<RootLayout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/academic-tools" element={<AcademicToolsPage />} />
            <Route path="/academic-tools/cgpa-calculator" element={<CgpaCalculatorPage />} />
            <Route path="/academic-tools/sgpa-calculator" element={<SgpaCalculatorPage />} />
            <Route path="/academic-tools/attendance-calculator" element={<AttendanceCalculatorPage />} />
            <Route path="/academic-tools/percentage-calculator" element={<PercentageCalculatorPage />} />
            <Route path="/academic-tools/gpa-to-percentage" element={<GpaToPercentagePage />} />
            <Route path="/academic-tools/semester-percentage-calculator" element={<SemesterPercentagePage />} />
            <Route path="/academic-tools/marks-required-calculator" element={<MarksRequiredPage />} />
            <Route path="/academic-tools/budget-planner" element={<BudgetPlannerPage />} />
            <Route path="/academic-tools/scientific-calculator" element={<ScientificCalculatorPage />} />
            <Route path="/academic-tools/assignment-score-calculator" element={<AssignmentScorePage />} />
            <Route path="/academic-tools/exam-score-calculator" element={<ExamScorePage />} />
            <Route path="/academic-tools/study-hours-calculator" element={<StudyHoursPage />} />
            <Route path="/academic-tools/deadline-calculator" element={<DeadlineCalculatorPage />} />
            <Route path="/academic-tools/unit-converter" element={<UnitConverterPage />} />

            <Route path="/productivity" element={<ProductivityIndexPage />} />
            <Route path="/productivity/todo-list" element={<TodoListPage />} />
            <Route path="/productivity/notes" element={<NotesPage />} />
            <Route path="/productivity/study-planner" element={<StudyPlannerPage />} />
            <Route path="/productivity/pomodoro-timer" element={<PomodoroTimerPage />} />
            <Route path="/productivity/goal-tracker" element={<GoalTrackerPage />} />
            <Route path="/productivity/habit-tracker" element={<HabitTrackerPage />} />
            <Route path="/productivity/exam-countdown" element={<ExamCountdownPage />} />
            <Route path="/productivity/weekly-planner" element={<WeeklyPlannerPage />} />
            <Route path="/document-tools" element={<DocumentToolsIndexPage />} />
            <Route path="/document-tools/merge-pdf" element={<MergePdfPage />} />
            <Route path="/document-tools/split-pdf" element={<SplitPdfPage />} />
            <Route path="/document-tools/compress-pdf" element={<CompressPdfPage />} />
            <Route path="/document-tools/rotate-pdf" element={<RotatePdfPage />} />
            <Route path="/document-tools/rearrange-pdf" element={<RearrangePdfPage />} />
            <Route path="/document-tools/extract-pdf-pages" element={<ExtractPdfPagesPage />} />
            <Route path="/document-tools/delete-pdf-pages" element={<DeletePdfPagesPage />} />
            <Route path="/document-tools/image-to-pdf" element={<ImageToPdfPage />} />
            <Route path="/document-tools/pdf-to-image" element={<PdfToImagePage />} />
            <Route path="/document-tools/word-to-pdf" element={<WordToPdfPage />} />
            <Route path="/document-tools/pdf-to-text" element={<PdfTextExtractPage />} />
            <Route path="/document-tools/ocr-architecture" element={<OcrArchitecturePage />} />
            <Route path="/document-tools/image-compressor" element={<ImageCompressorPage />} />
            <Route path="/document-tools/image-resizer" element={<ImageResizerPage />} />
            <Route path="/document-tools/image-cropper" element={<ImageCropperPage />} />
            <Route path="/document-tools/image-format-converter" element={<ImageFormatConverterPage />} />
            <Route path="/document-tools/jpg-png-converter" element={<JpgPngConverterPage />} />
            <Route path="/document-tools/webp-converter" element={<WebpConverterPage />} />
            <Route path="/document-tools/image-metadata-viewer" element={<ImageMetadataViewerPage />} />
            <Route path="/document-tools/qr-code-generator" element={<QrGeneratorPage />} />
            <Route path="/document-tools/qr-code-scanner" element={<QrScannerPage />} />
            <Route path="/document-tools/barcode-generator" element={<BarcodeGeneratorPage />} />
            <Route path="/creator-tools" element={<CreatorToolsPage />} />
            <Route path="/finance-tools" element={<FinanceToolsPage />} />
            <Route path="/blog" element={<BlogPage />} />

            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/disclaimer" element={<DisclaimerPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />

            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
