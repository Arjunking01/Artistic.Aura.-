import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, GraduationCap, ListTodo, FileText, Palette, Wallet, Sparkles } from 'lucide-react';
import { Seo, SITE_URL, SITE_NAME } from '@/components/Seo';
import { academicTools } from '@/data/toolsRegistry';

const CATEGORIES = [
  { icon: GraduationCap, title: 'Academic Tools', desc: '14 calculators for grades, attendance, and study planning.', href: '/academic-tools', live: true },
  { icon: ListTodo, title: 'Productivity', desc: 'Planners, trackers, and focus tools for daily momentum.', href: '/productivity', live: false },
  { icon: FileText, title: 'Document Tools', desc: 'Merge, compress, and convert PDFs and images.', href: '/document-tools', live: false },
  { icon: Palette, title: 'Creator Tools', desc: 'Thumbnail, title, and palette helpers for content creators.', href: '/creator-tools', live: false },
  { icon: Wallet, title: 'Finance Tools', desc: 'EMI, SIP, and budgeting calculators for student finances.', href: '/finance-tools', live: false },
];

export default function HomePage() {
  return (
    <div className="noise-bg">
      <Seo
        title={`${SITE_NAME} — The Ultimate Student Productivity Platform`}
        description="Calculate, plan, organize, and study smarter with ALLROUNDER HELPER — free academic calculators, productivity tools, and document utilities built for students."
        path="/"
        jsonLd={[
          { '@context': 'https://schema.org', '@type': 'Organization', name: SITE_NAME, url: SITE_URL },
          { '@context': 'https://schema.org', '@type': 'WebSite', name: SITE_NAME, url: SITE_URL, potentialAction: { '@type': 'SearchAction', target: `${SITE_URL}/blog?q={search_term_string}`, 'query-input': 'required name=search_term_string' } },
        ]}
      />

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 pt-16 sm:pt-24 pb-20 text-center">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-navy-200 dark:border-white/10 px-3 py-1 text-xs font-medium text-navy-500 dark:text-ink-400 mb-6">
            <Sparkles size={12} className="text-electric-500" /> Built for students, from day one
          </span>
          <h1 className="text-4xl sm:text-6xl font-semibold leading-[1.05] max-w-3xl mx-auto">
            Calculate. Plan. <span className="text-gradient-brand">Study smarter.</span>
          </h1>
          <p className="mt-5 text-lg text-navy-500 dark:text-ink-400 max-w-xl mx-auto">
            One platform for grade calculators, study planning, and the everyday tools that keep student life organized.
          </p>
          <div className="mt-8 flex items-center justify-center gap-3">
            <Link to="/academic-tools" className="inline-flex items-center gap-2 rounded-2xl gradient-brand text-white font-semibold px-6 py-3.5 shadow-lg shadow-electric-500/20 hover:brightness-110 transition-all">
              Explore Academic Tools <ArrowRight size={16} />
            </Link>
            <Link to="/about" className="inline-flex items-center gap-2 rounded-2xl border border-navy-200 dark:border-white/15 font-semibold px-6 py-3.5 hover:bg-navy-50 dark:hover:bg-white/5 transition-colors">
              Learn more
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 pb-24">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CATEGORIES.map((cat, i) => (
            <motion.div key={cat.title} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.3, delay: i * 0.05 }}>
              <Link to={cat.href} className="group relative flex flex-col gap-3 rounded-2xl glass-panel p-6 h-full hover:-translate-y-0.5 transition-transform">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl gradient-brand text-white">
                  <cat.icon size={20} />
                </div>
                <h3 className="font-semibold text-lg group-hover:text-electric-500 transition-colors">{cat.title}</h3>
                <p className="text-sm text-navy-500 dark:text-ink-400">{cat.desc}</p>
                {!cat.live && (
                  <span className="absolute top-5 right-5 text-[10px] font-semibold uppercase tracking-wide text-violet-500 bg-violet-500/10 rounded-full px-2 py-1">
                    Coming soon
                  </span>
                )}
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured academic tools */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 pb-24">
        <div className="flex items-end justify-between mb-6">
          <h2 className="text-2xl sm:text-3xl font-semibold">Popular academic tools</h2>
          <Link to="/academic-tools" className="text-sm font-medium text-electric-500 hover:underline flex items-center gap-1">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {academicTools.slice(0, 8).map((tool) => (
            <Link
              key={tool.slug}
              to={`/academic-tools/${tool.slug}`}
              className="group flex flex-col gap-2 rounded-2xl border border-navy-100 dark:border-white/10 p-4 hover:border-electric-500 transition-colors"
            >
              <tool.icon size={18} className="text-electric-500" />
              <span className="font-medium text-sm group-hover:text-electric-500 transition-colors">{tool.shortName}</span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
