import { Mail } from 'lucide-react';
import { StaticPageLayout } from '@/components/StaticPageLayout';

export default function ContactPage() {
  return (
    <StaticPageLayout title="Contact Us" description="Get in touch with the ALLROUNDER HELPER team for feedback, bug reports, or partnership inquiries." path="/contact">
      <p>We read every message. Whether you've spotted a calculation that looks off, have a tool you'd like to see built, or want to talk partnerships, reach out below.</p>
      <div className="flex items-center gap-3 rounded-2xl border border-navy-100 dark:border-white/10 p-5 not-prose">
        <Mail size={20} className="text-electric-500" />
        <div>
          <p className="text-sm text-navy-500 dark:text-ink-500">Email us at</p>
          <a href="mailto:hello@allrounderhelper.com" className="font-semibold text-navy-900 dark:text-ink-100 hover:text-electric-500 transition-colors">
            hello@allrounderhelper.com
          </a>
        </div>
      </div>
      <p>We typically respond within two business days.</p>
    </StaticPageLayout>
  );
}
