import { StaticPageLayout } from '@/components/StaticPageLayout';

export default function DisclaimerPage() {
  return (
    <StaticPageLayout title="Disclaimer" description="ALLROUNDER HELPER's calculators are provided for informational purposes and do not replace official academic or financial records." path="/disclaimer">
      <p>The calculators and tools on ALLROUNDER HELPER are built to closely follow standard academic and financial formulas, but they are provided for informational and planning purposes only.</p>
      <p>Results — including CGPA, SGPA, attendance projections, and financial estimates — should always be cross-checked against your institution's official records, transcripts, or a qualified financial advisor before being used for formal decisions such as applications, appeals, or loan agreements.</p>
      <p>We are not liable for decisions made solely on the basis of results produced by this site.</p>
    </StaticPageLayout>
  );
}
