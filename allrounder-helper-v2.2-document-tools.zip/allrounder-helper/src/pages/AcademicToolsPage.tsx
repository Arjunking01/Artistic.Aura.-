import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Seo, SITE_URL } from '@/components/Seo';
import { Breadcrumbs, breadcrumbJsonLd } from '@/components/ui/Breadcrumbs';
import { academicTools } from '@/data/toolsRegistry';

export default function AcademicToolsPage() {
  return (
    <div className="noise-bg">
      <Seo
        title="Academic Tools"
        description="Free academic calculators for students — CGPA, SGPA, attendance, percentage, exam scores, study planning, and more."
        path="/academic-tools"
        jsonLd={breadcrumbJsonLd([{ label: 'Academic Tools' }], SITE_URL)}
      />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 pt-8">
        <Breadcrumbs items={[{ label: 'Academic Tools' }]} />
      </div>
      <header className="mx-auto max-w-6xl px-4 sm:px-6 pt-8 pb-10">
        <h1 className="text-3xl sm:text-4xl font-semibold">Academic Tools</h1>
        <p className="mt-3 text-navy-500 dark:text-ink-400 max-w-2xl">
          Fourteen free calculators covering grades, attendance, budgeting, and study planning — built for accuracy and speed on any device.
        </p>
      </header>

      <div className="mx-auto max-w-6xl px-4 sm:px-6 pb-24 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {academicTools.map((tool, i) => (
          <motion.div
            key={tool.slug}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: i * 0.03 }}
          >
            <Link
              to={`/academic-tools/${tool.slug}`}
              className="group flex flex-col gap-3 rounded-2xl border border-navy-100 dark:border-white/10 p-5 hover:border-electric-500 hover:shadow-lg hover:shadow-electric-500/5 transition-all h-full"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-brand text-white">
                <tool.icon size={18} />
              </div>
              <div>
                <h2 className="font-semibold group-hover:text-electric-500 transition-colors">{tool.name}</h2>
                <p className="text-sm text-navy-500 dark:text-ink-500 mt-1">{tool.tagline}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
