import ComingSoonCategoryPage from './ComingSoonCategoryPage';

export default function CreatorToolsPage() {
  return (
    <ComingSoonCategoryPage
      title="Creator Tools"
      description="Thumbnail, title, and palette helpers for students building a content side hustle."
      path="/creator-tools"
      plannedTools={[
        'Thumbnail Checker', 'YouTube Title Helper', 'Description Generator', 'Hashtag Generator',
        'Color Picker', 'Gradient Generator', 'Palette Generator', 'DPI Calculator',
        'Resolution Calculator', 'Aspect Ratio Calculator',
      ]}
    />
  );
}
