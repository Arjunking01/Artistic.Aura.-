import ComingSoonCategoryPage from './ComingSoonCategoryPage';

export default function DocumentToolsPage() {
  return (
    <ComingSoonCategoryPage
      title="Document Tools"
      description="Merge, split, compress, and convert PDFs and images entirely in your browser."
      path="/document-tools"
      plannedTools={[
        'PDF Merge', 'PDF Split', 'Compress PDF', 'OCR',
        'Image to PDF', 'PDF to Image', 'JPG to PNG', 'PNG to JPG',
        'Image Compressor', 'Image Resizer', 'QR Generator', 'QR Scanner',
      ]}
    />
  );
}
