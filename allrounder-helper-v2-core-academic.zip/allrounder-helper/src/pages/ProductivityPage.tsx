import ComingSoonCategoryPage from './ComingSoonCategoryPage';

export default function ProductivityPage() {
  return (
    <ComingSoonCategoryPage
      title="Productivity"
      description="Study planners, habit trackers, and focus tools that save progress automatically in your browser."
      path="/productivity"
      plannedTools={[
        'Study Planner', 'Habit Tracker', 'Assignment Tracker', 'Semester Planner',
        'Calendar', 'Pomodoro Timer', 'To-do List', 'Notes',
        'Weekly Planner', 'Goal Tracker', 'Exam Countdown', 'Focus Mode',
      ]}
    />
  );
}
