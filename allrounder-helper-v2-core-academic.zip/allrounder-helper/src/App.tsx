import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { RootLayout } from '@/components/layout/RootLayout';

const HomePage = lazy(() => import('@/pages/HomePage'));
const AcademicToolsPage = lazy(() => import('@/pages/AcademicToolsPage'));
const ProductivityPage = lazy(() => import('@/pages/ProductivityPage'));
const DocumentToolsPage = lazy(() => import('@/pages/DocumentToolsPage'));
const CreatorToolsPage = lazy(() => import('@/pages/CreatorToolsPage'));
const FinanceToolsPage = lazy(() => import('@/pages/FinanceToolsPage'));
const BlogPage = lazy(() => import('@/pages/BlogPage'));
const AboutPage = lazy(() => import('@/pages/AboutPage'));
const ContactPage = lazy(() => import('@/pages/ContactPage'));
const PrivacyPolicyPage = lazy(() => import('@/pages/legal/PrivacyPolicyPage'));
const TermsPage = lazy(() => import('@/pages/legal/TermsPage'));
const DisclaimerPage = lazy(() => import('@/pages/legal/DisclaimerPage'));
const CookiePolicyPage = lazy(() => import('@/pages/legal/CookiePolicyPage'));
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage'));

const CgpaCalculatorPage = lazy(() => import('@/features/academic/pages/CgpaCalculatorPage'));
const SgpaCalculatorPage = lazy(() => import('@/features/academic/pages/SgpaCalculatorPage'));
const AttendanceCalculatorPage = lazy(() => import('@/features/academic/pages/AttendanceCalculatorPage'));
const PercentageCalculatorPage = lazy(() => import('@/features/academic/pages/PercentageCalculatorPage'));
const GpaToPercentagePage = lazy(() => import('@/features/academic/pages/GpaToPercentagePage'));
const SemesterPercentagePage = lazy(() => import('@/features/academic/pages/SemesterPercentagePage'));
const MarksRequiredPage = lazy(() => import('@/features/academic/pages/MarksRequiredPage'));
const BudgetPlannerPage = lazy(() => import('@/features/academic/pages/BudgetPlannerPage'));
const ScientificCalculatorPage = lazy(() => import('@/features/academic/pages/ScientificCalculatorPage'));
const AssignmentScorePage = lazy(() => import('@/features/academic/pages/AssignmentScorePage'));
const ExamScorePage = lazy(() => import('@/features/academic/pages/ExamScorePage'));
const StudyHoursPage = lazy(() => import('@/features/academic/pages/StudyHoursPage'));
const DeadlineCalculatorPage = lazy(() => import('@/features/academic/pages/DeadlineCalculatorPage'));
const UnitConverterPage = lazy(() => import('@/features/academic/pages/UnitConverterPage'));

function PageFallback() {
  return (
    <div className="flex min-h-[50vh] items-center justify-center">
      <div className="h-8 w-8 rounded-full border-2 border-electric-500 border-t-transparent animate-spin" />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<PageFallback />}>
        <Routes>
          <Route element={<RootLayout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/academic-tools" element={<AcademicToolsPage />} />
            <Route path="/academic-tools/cgpa-calculator" element={<CgpaCalculatorPage />} />
            <Route path="/academic-tools/sgpa-calculator" element={<SgpaCalculatorPage />} />
            <Route path="/academic-tools/attendance-calculator" element={<AttendanceCalculatorPage />} />
            <Route path="/academic-tools/percentage-calculator" element={<PercentageCalculatorPage />} />
            <Route path="/academic-tools/gpa-to-percentage" element={<GpaToPercentagePage />} />
            <Route path="/academic-tools/semester-percentage-calculator" element={<SemesterPercentagePage />} />
            <Route path="/academic-tools/marks-required-calculator" element={<MarksRequiredPage />} />
            <Route path="/academic-tools/budget-planner" element={<BudgetPlannerPage />} />
            <Route path="/academic-tools/scientific-calculator" element={<ScientificCalculatorPage />} />
            <Route path="/academic-tools/assignment-score-calculator" element={<AssignmentScorePage />} />
            <Route path="/academic-tools/exam-score-calculator" element={<ExamScorePage />} />
            <Route path="/academic-tools/study-hours-calculator" element={<StudyHoursPage />} />
            <Route path="/academic-tools/deadline-calculator" element={<DeadlineCalculatorPage />} />
            <Route path="/academic-tools/unit-converter" element={<UnitConverterPage />} />

            <Route path="/productivity" element={<ProductivityPage />} />
            <Route path="/document-tools" element={<DocumentToolsPage />} />
            <Route path="/creator-tools" element={<CreatorToolsPage />} />
            <Route path="/finance-tools" element={<FinanceToolsPage />} />
            <Route path="/blog" element={<BlogPage />} />

            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/disclaimer" element={<DisclaimerPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />

            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
